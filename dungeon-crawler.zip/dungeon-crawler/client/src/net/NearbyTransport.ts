import { registerPlugin, type PluginListenerHandle } from '@capacitor/core';
import type { ClientMsg, ServerMsg } from '../../../shared/src/protocol';
import type { ClientTransport, HostInfo, HostTransport, TransportFactory } from './Transport';

interface NearbyEvent { endpointId: string; name?: string; data?: string }

/** Native Android plugin (client/native/android/NearbyPlugin.java) wrapping Google Nearby Connections. */
interface NearbyPlugin {
  ensurePermissions(): Promise<void>;
  startAdvertising(o: { name: string }): Promise<void>;
  startDiscovery(): Promise<void>;
  connect(o: { endpointId: string; name: string }): Promise<void>;
  send(o: { endpointId: string; data: string }): Promise<void>;
  broadcast(o: { data: string }): Promise<void>;
  disconnect(o: { endpointId: string }): Promise<void>;
  stopAll(): Promise<void>;
  addListener(event: string, cb: (e: NearbyEvent) => void): Promise<PluginListenerHandle>;
}

const Nearby = registerPlugin<NearbyPlugin>('Nearby');

function parse<T>(data: string | undefined): T | null {
  if (!data) return null;
  try { return JSON.parse(data) as T; } catch { return null; }
}

class NearbyHost implements HostTransport {
  private handles: PluginListenerHandle[] = [];
  private peerCb: (id: string, name: string, up: boolean) => void = () => {};
  private msgCb: (id: string, m: ClientMsg) => void = () => {};

  onPeer(cb: (id: string, name: string, up: boolean) => void): void { this.peerCb = cb; }
  onMessage(cb: (id: string, m: ClientMsg) => void): void { this.msgCb = cb; }

  async start(hostName: string): Promise<void> {
    await Nearby.ensurePermissions();
    this.handles.push(
      await Nearby.addListener('connected', (e) => this.peerCb(e.endpointId, e.name ?? 'Hero', true)),
      await Nearby.addListener('disconnected', (e) => this.peerCb(e.endpointId, '', false)),
      await Nearby.addListener('message', (e) => {
        const m = parse<ClientMsg>(e.data);
        if (m) this.msgCb(e.endpointId, m);
      }),
    );
    await Nearby.startAdvertising({ name: hostName });
  }
  async stop(): Promise<void> {
    await Nearby.stopAll().catch(() => {});
    await Promise.all(this.handles.map((h) => h.remove()));
    this.handles = [];
  }
  sendTo(id: string, msg: ServerMsg): void { void Nearby.send({ endpointId: id, data: JSON.stringify(msg) }).catch(() => {}); }
  broadcast(msg: ServerMsg): void { void Nearby.broadcast({ data: JSON.stringify(msg) }).catch(() => {}); }
  kick(id: string): void { void Nearby.disconnect({ endpointId: id }).catch(() => {}); }
}

class NearbyClient implements ClientTransport {
  private handles: PluginListenerHandle[] = [];
  private hosts = new Map<string, HostInfo>();
  private hostId: string | null = null;
  private msgCb: (m: ServerMsg) => void = () => {};
  private closeCb: () => void = () => {};

  onMessage(cb: (m: ServerMsg) => void): void { this.msgCb = cb; }
  onClose(cb: () => void): void { this.closeCb = cb; }

  async discover(cb: (hosts: HostInfo[]) => void): Promise<void> {
    await Nearby.ensurePermissions();
    const push = () => cb([...this.hosts.values()]);
    this.handles.push(
      await Nearby.addListener('endpointFound', (e) => { this.hosts.set(e.endpointId, { id: e.endpointId, name: e.name ?? 'Game' }); push(); }),
      await Nearby.addListener('endpointLost', (e) => { this.hosts.delete(e.endpointId); push(); }),
      await Nearby.addListener('message', (e) => {
        const m = parse<ServerMsg>(e.data);
        if (m) this.msgCb(m);
      }),
      await Nearby.addListener('disconnected', (e) => { if (e.endpointId === this.hostId) this.closeCb(); }),
    );
    await Nearby.startDiscovery();
  }
  async stopDiscover(): Promise<void> { /* native side stops discovery when a connection is requested */ }

  connect(hostId: string, myName: string): Promise<void> {
    this.hostId = hostId;
    return new Promise<void>(async (resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Connection timed out')), 12000);
      const ok = await Nearby.addListener('connected', (e) => { if (e.endpointId === hostId) { clearTimeout(timer); resolve(); } });
      const bad = await Nearby.addListener('connectFailed', () => { clearTimeout(timer); reject(new Error('Host refused the connection')); });
      this.handles.push(ok, bad);
      Nearby.connect({ endpointId: hostId, name: myName }).catch((err: Error) => { clearTimeout(timer); reject(err); });
    });
  }
  send(msg: ClientMsg): void { if (this.hostId) void Nearby.send({ endpointId: this.hostId, data: JSON.stringify(msg) }).catch(() => {}); }
  async close(): Promise<void> {
    await Nearby.stopAll().catch(() => {});
    await Promise.all(this.handles.map((h) => h.remove()));
    this.handles = [];
    this.hostId = null;
  }
}

export const nearbyTransport: TransportFactory = {
  label: 'Bluetooth / Wi-Fi',
  host: () => new NearbyHost(),
  client: () => new NearbyClient(),
};
