/** Pure data. Add a new enemy or boss by adding an entry here; no code changes needed. */
export interface EnemyDef {
  id: string;
  name: string;
  hp: number;
  speed: number;
  damage: number;
  radius: number;
  aggroRange: number;
  leashRange: number;
  attackRange: number;
  windupMs: number;
  recoverMs: number;
  color: number;
}

export type PatternKind = 'cleave' | 'slam' | 'fan' | 'summon';

export interface PatternDef {
  id: string;
  kind: PatternKind;
  windupMs: number;   // telegraph time players can react in
  recoverMs: number;  // punish window
  damage: number;
  range: number;
  radius: number;
  arcDeg: number;
  count: number;      // summon count
  summonKind?: string;
}

export interface BossPhase {
  hpPct: number;      // phase begins when boss HP fraction <= this
  speedMul: number;
  patterns: PatternDef[];            // cycled in order
  onEnterSummon?: { kind: string; count: number };
}

export interface BossDef extends EnemyDef { phases: BossPhase[] }

export const MINIONS: Record<string, EnemyDef> = {
  grunt: { id: 'grunt', name: 'Crypt Grunt', hp: 60, speed: 85, damage: 10, radius: 14, aggroRange: 380, leashRange: 700, attackRange: 40, windupMs: 450, recoverMs: 600, color: 0xc2574f },
  brute: { id: 'brute', name: 'Bone Brute', hp: 150, speed: 60, damage: 22, radius: 20, aggroRange: 320, leashRange: 650, attackRange: 55, windupMs: 750, recoverMs: 900, color: 0x8a4fc2 },
};

export const BOSSES: Record<string, BossDef> = {
  warden: {
    id: 'warden', name: 'The Hollow Warden', hp: 900, speed: 70, damage: 0, radius: 42,
    aggroRange: 2000, leashRange: 4000, attackRange: 0, windupMs: 0, recoverMs: 0, color: 0xe0a030,
    phases: [
      {
        hpPct: 1.0, speedMul: 1.0,
        patterns: [
          { id: 'sweep', kind: 'cleave', windupMs: 900, recoverMs: 800, damage: 28, range: 150, radius: 0, arcDeg: 140, count: 0 },
          { id: 'stomp', kind: 'slam', windupMs: 1100, recoverMs: 900, damage: 30, range: 0, radius: 170, arcDeg: 0, count: 0 },
        ],
      },
      {
        hpPct: 0.6, speedMul: 1.2,
        onEnterSummon: { kind: 'grunt', count: 3 },
        patterns: [
          { id: 'sweep', kind: 'cleave', windupMs: 750, recoverMs: 600, damage: 32, range: 160, radius: 0, arcDeg: 150, count: 0 },
          { id: 'volley', kind: 'fan', windupMs: 900, recoverMs: 700, damage: 22, range: 420, radius: 0, arcDeg: 70, count: 0 },
          { id: 'stomp', kind: 'slam', windupMs: 900, recoverMs: 700, damage: 34, range: 0, radius: 190, arcDeg: 0, count: 0 },
        ],
      },
      {
        hpPct: 0.3, speedMul: 1.45,
        onEnterSummon: { kind: 'brute', count: 1 },
        patterns: [
          { id: 'sweep', kind: 'cleave', windupMs: 600, recoverMs: 450, damage: 36, range: 170, radius: 0, arcDeg: 160, count: 0 },
          { id: 'volley', kind: 'fan', windupMs: 650, recoverMs: 450, damage: 26, range: 460, radius: 0, arcDeg: 90, count: 0 },
          { id: 'call', kind: 'summon', windupMs: 800, recoverMs: 500, damage: 0, range: 0, radius: 0, arcDeg: 0, count: 2, summonKind: 'grunt' },
          { id: 'stomp', kind: 'slam', windupMs: 700, recoverMs: 500, damage: 40, range: 0, radius: 210, arcDeg: 0, count: 0 },
        ],
      },
    ],
  },
};

/** Encounter script: rooms of minions, then the boss. */
export const RUN_SCRIPT: Array<{ minions: Record<string, number> } | { boss: string }> = [
  { minions: { grunt: 4 } },
  { minions: { grunt: 3, brute: 1 } },
  { boss: 'warden' },
];

/** HP scales with party size and floor; damage only with floor. */
export function scaledHp(base: number, players: number, floor: number): number {
  return Math.round(base * (1 + 0.65 * (players - 1)) * (1 + 0.25 * (floor - 1)));
}
export function scaledDamage(base: number, floor: number): number {
  return Math.round(base * (1 + 0.15 * (floor - 1)));
}
