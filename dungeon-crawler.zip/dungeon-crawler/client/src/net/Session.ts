import { HostSim } from '../../../shared/src/sim/HostSim';
import { TICK_MS } from '../../../shared/src/protocol';
import type { ClientMsg, EnemyView, FxMsg, Phase, PlayerState, ServerMsg, Snapshot } from '../../../shared/src/protocol';
import type { ClientTransport, HostTransport } from './Transport';

/** What every scene reads. Identical on the host and on joiners. */
export interface GameView {
  myId: string;
  phase: Phase;
  roomIndex: number;
  players: Map<string, PlayerState>;
  enemies: Map<string, EnemyView>;
}

export abstract class Session {
  readonly view: GameView = { myId: '', phase: 'lobby', roomIndex: 0, players: new Map(), enemies: new Map() };
  abstract readonly isHost: boolean;
  protected fxCbs: Array<(f: FxMsg) => void> = [];
  protected closeCbs: Array<() => void> = [];
  protected closed = false;

  abstract send(msg: ClientMsg): void;
  abstract leave(): Promise<void>;
  onFx(cb: (f: FxMsg) => void): void { this.fxCbs.push(cb); }
  onClose(cb: () => void): void { this.closeCbs.push(cb); }

  protected apply(s: Snapshot): void {
    const v = this.view;
    v.phase = s.phase;
    v.roomIndex = s.roomIndex;
    v.players.clear();
    for (const p of s.players) v.players.set(p.id, p);
    v.enemies.clear();
    for (const e of s.enemies) v.enemies.set(e.id, e);
  }
}

export const Current: { session: Session | null } = { session: null };

/** The host phone: runs the real game and relays snapshots to joiners. transport=null means solo. */
export class HostSession extends Session {
  readonly isHost = true;
  private sim: HostSim;
  private timer = 0;
  private last = 0;

  constructor(private transport: HostTransport | null, private name: string) {
    super();
    this.view.myId = 'host';
    this.sim = new HostSim({
      fx: (fx) => { this.fxCbs.forEach((cb) => cb(fx)); this.transport?.broadcast({ t: 'fx', fx }); },
    });
  }

  async start(): Promise<void> {
    this.sim.addPlayer('host', this.name);
    const t = this.transport;
    if (t) {
      t.onPeer((id, name, up) => {
        if (!up) { this.sim.removePlayer(id); return; }
        if (this.sim.addPlayer(id, name)) t.sendTo(id, { t: 'welcome', id });
        else t.kick(id); // full or run already started
      });
      t.onMessage((id, msg) => this.sim.handle(id, msg));
      await t.start(this.name);
    }
    this.last = performance.now();
    this.timer = window.setInterval(() => {
      const now = performance.now();
      this.sim.tick(Math.min(now - this.last, 100));
      this.last = now;
      const snap = this.sim.snapshot();
      this.apply(snap);
      t?.broadcast(snap);
    }, TICK_MS);
  }

  send(msg: ClientMsg): void { this.sim.handle('host', msg); } // loopback: the host is also a player
  async leave(): Promise<void> {
    this.closed = true;
    clearInterval(this.timer);
    await this.transport?.stop();
  }
}

/** A joining phone: sends intent, renders whatever the host says. */
export class ClientSession extends Session {
  readonly isHost = false;
  constructor(private transport: ClientTransport) { super(); }

  async join(hostId: string, name: string): Promise<void> {
    const welcomed = new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Host did not answer (is the lobby full?)')), 8000);
      this.transport.onMessage((m: ServerMsg) => {
        if (m.t === 'welcome') { this.view.myId = m.id; clearTimeout(timer); resolve(); }
        else if (m.t === 'snap') this.apply(m);
        else if (m.t === 'fx') this.fxCbs.forEach((cb) => cb(m.fx));
      });
    });
    this.transport.onClose(() => { if (!this.closed) this.closeCbs.forEach((cb) => cb()); });
    await this.transport.connect(hostId, name);
    await welcomed;
  }

  send(msg: ClientMsg): void { this.transport.send(msg); }
  async leave(): Promise<void> { this.closed = true; await this.transport.close(); }
}
