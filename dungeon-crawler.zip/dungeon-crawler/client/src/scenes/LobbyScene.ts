import Phaser from 'phaser';
import { getTransport } from '../net';
import { ClientSession, Current, HostSession, Session } from '../net/Session';
import type { HostInfo } from '../net/Transport';
import { CLASSES, ClassId } from '../../../shared/src/classes';
import { button, label } from './ui';
import type { Mode } from './MenuScene';

export class LobbyScene extends Phaser.Scene {
  private status!: Phaser.GameObjects.Text;
  private roster!: Phaser.GameObjects.Text;
  private hostButtons: Phaser.GameObjects.GameObject[] = [];
  private readyBtn!: Phaser.GameObjects.Container;
  private ready = false;
  private myName = 'Hero' + Math.floor(Math.random() * 90 + 10);

  constructor() { super('Lobby'); }

  create(): void {
    const { width: w, height: h } = this.scale;
    this.ready = false;
    this.hostButtons = [];
    label(this, w / 2, 36, 'Lobby', 30);
    this.status = label(this, w / 2, 80, '', 18, '#8b93a7');
    this.roster = label(this, w / 2, 240, '', 22).setAlign('left').setLineSpacing(10);

    this.readyBtn = button(this, w / 2, h - 100, 280, 'Ready', () => {
      this.ready = !this.ready;
      Current.session?.send({ t: 'ready', ready: this.ready });
      (this.readyBtn.list[1] as Phaser.GameObjects.Text).setText(this.ready ? 'Cancel Ready' : 'Ready');
    }).setVisible(false);
    button(this, 110, h - 40, 160, 'Leave', async () => { await this.teardown(); this.scene.start('Menu'); }, 48);

    const mode = this.registry.get('mode') as Mode;
    const run = mode === 'join' ? this.runJoin() : this.runHost(mode === 'host');
    run.catch((err: Error) => this.status.setText(`${err.message || 'Could not start.'}`).setColor('#e06060'));
  }

  private async teardown(): Promise<void> {
    await Current.session?.leave();
    Current.session = null;
  }

  private enterLobby(session: Session, text: string): void {
    Current.session = session;
    session.send({ t: 'class', classId: this.registry.get('classId') as string });
    session.onClose(() => { if (this.scene.isActive('Lobby')) this.scene.start('Menu'); });
    this.status.setText(text).setColor('#8b93a7');
    this.readyBtn.setVisible(true);
    this.hostButtons.forEach((o) => o.destroy());
    this.hostButtons = [];
  }

  private async runHost(multiplayer: boolean): Promise<void> {
    this.status.setText('Starting…');
    const tf = multiplayer ? getTransport() : null;
    const s = new HostSession(tf?.host() ?? null, this.myName);
    await s.start();
    this.enterLobby(s, multiplayer ? `Hosting as ${this.myName}. Friends: tap “Join Game” on your phone.` : 'Solo run. Tap Ready.');
  }

  private async runJoin(): Promise<void> {
    const tf = getTransport();
    if (!tf) throw new Error('Multiplayer is not available here.');
    this.status.setText('Looking for nearby games…');
    const transport = tf.client();
    await transport.discover((hosts) => this.renderHosts(hosts, async (host) => {
      try {
        this.status.setText(`Joining ${host.name}…`);
        await transport.stopDiscover();
        const s = new ClientSession(transport);
        await s.join(host.id, this.myName);
        this.enterLobby(s, `Joined ${host.name}. Tap Ready.`);
      } catch (err) {
        this.status.setText((err as Error).message).setColor('#e06060');
        await transport.close();
        this.scene.start('Menu');
      }
    }));
  }

  private renderHosts(hosts: HostInfo[], onPick: (h: HostInfo) => void): void {
    if (Current.session) return;
    this.hostButtons.forEach((o) => o.destroy());
    this.hostButtons = hosts.slice(0, 4).map((h, i) => button(this, this.scale.width / 2, 170 + i * 70, 420, h.name, () => onPick(h)));
    this.status.setText(hosts.length ? 'Tap a game to join' : 'Looking for nearby games… (ask the host to tap Host Game)');
  }

  update(): void {
    const s = Current.session;
    if (!s) return;
    const lines: string[] = [];
    s.view.players.forEach((p) => lines.push(`${p.ready ? '✔' : '○'}  ${p.name}  —  ${CLASSES[p.classId as ClassId]?.name ?? '?'}`));
    this.roster.setText(lines.join('\n'));
    if (s.view.phase === 'playing') this.scene.start('Game');
  }
}
