#!/usr/bin/env bash
# One-click APK builder (macOS / Linux): bash build-apk.sh
cd "$(dirname "$0")" && node scripts/build-apk.mjs
