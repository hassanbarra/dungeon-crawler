import { ARENA, clamp } from '../protocol';
import { dist } from '../geometry';
import { EnemyDef, scaledDamage, scaledHp } from '../enemies';
import { StateMachine } from './fsm';
import type { AIWorld, Target } from './world';

export interface Scaling { players: number; floor: number }

export abstract class Enemy {
  x: number;
  y: number;
  hp: number;
  readonly maxHp: number;
  readonly damage: number;
  phase = 0;
  facing = 0;
  invulnerable = false;
  targetId: string | null = null;
  stateName = 'idle';
  protected world!: AIWorld;
  protected fsm: StateMachine<Enemy>;

  constructor(readonly id: string, readonly def: EnemyDef, x: number, y: number, scale: Scaling) {
    this.x = x;
    this.y = y;
    this.maxHp = this.hp = scaledHp(def.hp, scale.players, scale.floor);
    this.damage = scaledDamage(def.damage, scale.floor);
    this.fsm = new StateMachine<Enemy>(this);
  }

  get dead(): boolean { return this.hp <= 0; }

  update(dtMs: number, world: AIWorld): void {
    this.world = world;
    if (this.dead) {
      if (this.fsm.currentName !== 'dead') this.fsm.go('dead');
    } else {
      this.beforeUpdate();
      this.fsm.update(dtMs);
    }
    this.stateName = this.fsm.currentName;
  }

  /** Hook for subclasses (boss phase checks). */
  protected beforeUpdate(): void {}

  takeDamage(amount: number): boolean {
    if (this.invulnerable || this.dead) return false;
    this.hp = Math.max(0, this.hp - amount);
    return true;
  }

  protected target(): Target | null {
    return this.world.players().find((p) => p.id === this.targetId) ?? null;
  }

  protected nearestPlayer(): Target | null {
    let best: Target | null = null;
    let bestD = Infinity;
    for (const p of this.world.players()) {
      const d = dist(this.x, this.y, p.x, p.y);
      if (d < bestD) { best = p; bestD = d; }
    }
    return best;
  }

  protected distTo(t: Target): number { return dist(this.x, this.y, t.x, t.y); }

  protected moveToward(t: Target, speedMul: number, dtMs: number): void {
    this.facing = Math.atan2(t.y - this.y, t.x - this.x);
    const step = (this.def.speed * speedMul * dtMs) / 1000;
    this.x = clamp(this.x + Math.cos(this.facing) * step, 20, ARENA.w - 20);
    this.y = clamp(this.y + Math.sin(this.facing) * step, 20, ARENA.h - 20);
  }
}
