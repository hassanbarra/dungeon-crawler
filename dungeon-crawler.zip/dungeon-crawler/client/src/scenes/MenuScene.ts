import Phaser from 'phaser';
import { getTransport } from '../net';
import { button, label } from './ui';

export type Mode = 'host' | 'join' | 'solo';

export class MenuScene extends Phaser.Scene {
  constructor() { super('Menu'); }

  create(): void {
    const { width: w } = this.scale;
    const transport = getTransport();
    label(this, w / 2, 100, 'DUNGEON CRAWLER', 52, '#e0a030');
    label(this, w / 2, 148, 'Local co-op. No internet needed.', 18, '#8b93a7');

    const go = (mode: Mode) => { this.registry.set('mode', mode); this.scene.start('ClassSelect'); };
    if (transport) {
      button(this, w / 2, 240, 340, 'Host Game  (up to 4 players)', () => go('host'));
      button(this, w / 2, 315, 340, 'Join Game', () => go('join'));
      button(this, w / 2, 390, 340, 'Play Solo', () => go('solo'));
      label(this, w / 2, 455, `Players connect directly over ${transport.label}.`, 14, '#8b93a7');
      label(this, w / 2, 478, 'Stay within a few metres of the host.', 14, '#8b93a7');
    } else {
      button(this, w / 2, 280, 340, 'Play Solo', () => go('solo'));
      label(this, w / 2, 360, 'Bluetooth / Wi-Fi multiplayer needs the Android app.', 15, '#c9a14a');
    }
  }
}
