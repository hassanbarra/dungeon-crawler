"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Minion = void 0;
const Enemy_1 = require("./Enemy");
/** idle -> chase -> attack(windup, strike, recover) -> chase ... -> dead */
class Minion extends Enemy_1.Enemy {
    t = 0;
    struck = false;
    constructor(id, def, x, y, scale) {
        super(id, def, x, y, scale);
        this.fsm
            .add({
            name: 'idle',
            update: () => {
                const p = this.nearestPlayer();
                if (p && this.distTo(p) <= def.aggroRange) {
                    this.targetId = p.id;
                    return 'chase';
                }
            },
        })
            .add({
            name: 'chase',
            update: (_o, dt) => {
                const p = this.target() ?? this.nearestPlayer();
                if (!p || this.distTo(p) > def.leashRange) {
                    this.targetId = null;
                    return 'idle';
                }
                this.targetId = p.id;
                if (this.distTo(p) <= def.attackRange)
                    return 'attack';
                this.moveToward(p, 1, dt);
            },
        })
            .add({
            name: 'attack',
            enter: () => {
                this.t = 0;
                this.struck = false;
                const p = this.target();
                if (p)
                    this.facing = Math.atan2(p.y - this.y, p.x - this.x);
                this.world.fx({ kind: 'telegraph', x: this.x, y: this.y, r: def.attackRange + 10, ms: def.windupMs, angle: this.facing, arc: 90 });
            },
            update: (_o, dt) => {
                this.t += dt;
                if (!this.struck && this.t >= def.windupMs) {
                    this.struck = true;
                    this.world.damageCone(this.x, this.y, this.facing, 90, def.attackRange + 10, this.damage);
                }
                if (this.t >= def.windupMs + def.recoverMs)
                    return 'chase';
            },
        })
            .add({ name: 'dead', update: () => { } })
            .start('idle');
    }
}
exports.Minion = Minion;
