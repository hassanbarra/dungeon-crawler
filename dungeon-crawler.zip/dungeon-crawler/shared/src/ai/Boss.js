"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Boss = void 0;
const enemies_1 = require("../enemies");
const Enemy_1 = require("./Enemy");
const TRANSITION_MS = 1500;
/**
 * idle -> engage -> pattern(windup, execute, recover) -> engage ...
 * Crossing an HP threshold forces 'transition' (invulnerable, optional add wave).
 */
class Boss extends Enemy_1.Enemy {
    bossDef;
    t = 0;
    patternIdx = 0;
    cur = null;
    fired = false;
    floor;
    constructor(id, bossDef, x, y, scale) {
        super(id, bossDef, x, y, scale);
        this.bossDef = bossDef;
        this.floor = scale.floor;
        this.fsm
            .add({
            name: 'idle',
            update: () => {
                const p = this.nearestPlayer();
                if (p) {
                    this.targetId = p.id;
                    return 'engage';
                }
            },
        })
            .add({
            name: 'engage',
            enter: () => { this.t = 0; },
            update: (_o, dt) => {
                this.t += dt;
                const p = this.nearestPlayer();
                if (!p)
                    return 'idle';
                this.targetId = p.id;
                const speedMul = this.bossDef.phases[this.phase].speedMul;
                if (this.distTo(p) > 140 && this.t < 1800)
                    this.moveToward(p, speedMul, dt);
                else
                    return 'pattern';
            },
        })
            .add({
            name: 'pattern',
            enter: () => {
                const list = this.bossDef.phases[this.phase].patterns;
                this.cur = list[this.patternIdx++ % list.length];
                this.t = 0;
                this.fired = false;
                const p = this.target();
                if (p)
                    this.facing = Math.atan2(p.y - this.y, p.x - this.x);
                const c = this.cur;
                this.world.fx({
                    kind: 'telegraph', x: this.x, y: this.y, ms: c.windupMs, angle: this.facing,
                    r: c.kind === 'slam' ? c.radius : c.range || 120, arc: c.kind === 'slam' ? 360 : c.arcDeg || 360,
                });
            },
            update: (_o, dt) => {
                const c = this.cur;
                this.t += dt;
                if (!this.fired && this.t >= c.windupMs) {
                    this.fired = true;
                    this.execute(c);
                }
                if (this.t >= c.windupMs + c.recoverMs)
                    return 'engage';
            },
        })
            .add({
            name: 'transition',
            enter: () => {
                this.t = 0;
                this.invulnerable = true;
                this.patternIdx = 0;
                this.world.fx({ kind: 'phase', x: this.x, y: this.y, r: 260, ms: TRANSITION_MS });
                const add = this.bossDef.phases[this.phase].onEnterSummon;
                if (add)
                    for (let i = 0; i < add.count; i++)
                        this.spawnAdd(add.kind, i, add.count);
            },
            update: (_o, dt) => {
                this.t += dt;
                if (this.t >= TRANSITION_MS) {
                    this.invulnerable = false;
                    return 'engage';
                }
            },
            exit: () => { this.invulnerable = false; },
        })
            .add({ name: 'dead', update: () => { } })
            .start('idle');
    }
    beforeUpdate() {
        const next = this.phase + 1;
        if (next < this.bossDef.phases.length && this.hp / this.maxHp <= this.bossDef.phases[next].hpPct) {
            this.phase = next;
            this.fsm.go('transition');
        }
    }
    execute(c) {
        const dmg = (0, enemies_1.scaledDamage)(c.damage, this.floor);
        switch (c.kind) {
            case 'cleave':
            case 'fan':
                this.world.damageCone(this.x, this.y, this.facing, c.arcDeg, c.range, dmg);
                break;
            case 'slam':
                this.world.damageCircle(this.x, this.y, c.radius, dmg);
                break;
            case 'summon':
                for (let i = 0; i < c.count; i++)
                    this.spawnAdd(c.summonKind ?? 'grunt', i, c.count);
                break;
        }
    }
    spawnAdd(kind, i, n) {
        const a = (i / n) * Math.PI * 2;
        this.world.spawnMinion(kind, this.x + Math.cos(a) * 110, this.y + Math.sin(a) * 110);
    }
}
exports.Boss = Boss;
