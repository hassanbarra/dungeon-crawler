import Phaser from 'phaser';

/** Generates placeholder textures so the project runs with zero art assets. Swap for an atlas later. */
export class BootScene extends Phaser.Scene {
  constructor() { super('Boot'); }

  create(): void {
    const g = this.make.graphics({ x: 0, y: 0 }, false);
    g.fillStyle(0xffffff).fillCircle(16, 16, 16);
    g.generateTexture('dot', 32, 32);
    g.clear();
    g.fillStyle(0x151a24).fillRect(0, 0, 64, 64).lineStyle(1, 0x222a3a).strokeRect(0, 0, 64, 64);
    g.generateTexture('floor', 64, 64);
    g.destroy();
    this.scene.start('Menu');
  }
}
