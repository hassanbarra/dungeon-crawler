package __PACKAGE__;

import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.AdvertisingOptions;
import com.google.android.gms.nearby.connection.ConnectionInfo;
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback;
import com.google.android.gms.nearby.connection.ConnectionResolution;
import com.google.android.gms.nearby.connection.ConnectionsClient;
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo;
import com.google.android.gms.nearby.connection.DiscoveryOptions;
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback;
import com.google.android.gms.nearby.connection.Payload;
import com.google.android.gms.nearby.connection.PayloadCallback;
import com.google.android.gms.nearby.connection.PayloadTransferUpdate;
import com.google.android.gms.nearby.connection.Strategy;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Bluetooth / Wi-Fi peer-to-peer via Google Nearby Connections (P2P_STAR: one host, several joiners).
 * Needs Google Play services on every phone. Messages are UTF-8 JSON strings under 32 KB.
 */
@CapacitorPlugin(name = "Nearby")
public class NearbyPlugin extends Plugin {
  private static final String SERVICE_ID = "dungeoncrawler.nearby.v1";
  private static final int PERM_REQ = 7001;

  private ConnectionsClient client;
  private final Map<String, String> names = new HashMap<>();
  private final Set<String> connected = new HashSet<>();

  @Override
  public void load() {
    client = Nearby.getConnectionsClient(getContext());
  }

  // ---- permissions ---------------------------------------------------------
  private String[] missing() {
    List<String> want = new ArrayList<>();
    if (Build.VERSION.SDK_INT >= 33) {
      want.add("android.permission.BLUETOOTH_ADVERTISE");
      want.add("android.permission.BLUETOOTH_CONNECT");
      want.add("android.permission.BLUETOOTH_SCAN");
      want.add("android.permission.NEARBY_WIFI_DEVICES");
    } else if (Build.VERSION.SDK_INT >= 31) {
      want.add("android.permission.BLUETOOTH_ADVERTISE");
      want.add("android.permission.BLUETOOTH_CONNECT");
      want.add("android.permission.BLUETOOTH_SCAN");
      want.add("android.permission.ACCESS_FINE_LOCATION");
    } else {
      want.add("android.permission.ACCESS_FINE_LOCATION");
    }
    List<String> need = new ArrayList<>();
    for (String p : want) {
      if (ContextCompat.checkSelfPermission(getContext(), p) != PackageManager.PERMISSION_GRANTED) need.add(p);
    }
    return need.toArray(new String[0]);
  }

  @PluginMethod
  public void ensurePermissions(PluginCall call) {
    String[] need = missing();
    if (need.length == 0) { call.resolve(); return; }
    saveCall(call);
    pluginRequestPermissions(need, PERM_REQ);
  }

  @Override
  protected void handleRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    super.handleRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode != PERM_REQ) return;
    PluginCall call = getSavedCall();
    if (call == null) return;
    if (missing().length == 0) call.resolve();
    else call.reject("Bluetooth / nearby permission was denied. Enable it in Settings > Apps.");
    freeSavedCall();
  }

  // ---- callbacks -----------------------------------------------------------
  private JSObject obj(String id, String name) {
    JSObject o = new JSObject();
    o.put("endpointId", id);
    if (name != null) o.put("name", name);
    return o;
  }

  private final PayloadCallback payloadCb = new PayloadCallback() {
    @Override
    public void onPayloadReceived(String id, Payload payload) {
      if (payload.getType() != Payload.Type.BYTES) return;
      byte[] b = payload.asBytes();
      if (b == null) return;
      JSObject o = obj(id, null);
      o.put("data", new String(b, StandardCharsets.UTF_8));
      notifyListeners("message", o);
    }
    @Override
    public void onPayloadTransferUpdate(String id, PayloadTransferUpdate update) {}
  };

  private final ConnectionLifecycleCallback lifecycleCb = new ConnectionLifecycleCallback() {
    @Override
    public void onConnectionInitiated(String id, ConnectionInfo info) {
      names.put(id, info.getEndpointName());
      client.acceptConnection(id, payloadCb); // party game: auto-accept, no PIN prompt
    }
    @Override
    public void onConnectionResult(String id, ConnectionResolution result) {
      if (result.getStatus().isSuccess()) {
        connected.add(id);
        notifyListeners("connected", obj(id, names.get(id)));
      } else {
        notifyListeners("connectFailed", obj(id, names.get(id)));
      }
    }
    @Override
    public void onDisconnected(String id) {
      connected.remove(id);
      notifyListeners("disconnected", obj(id, names.get(id)));
    }
  };

  private final EndpointDiscoveryCallback discoveryCb = new EndpointDiscoveryCallback() {
    @Override
    public void onEndpointFound(String id, DiscoveredEndpointInfo info) {
      notifyListeners("endpointFound", obj(id, info.getEndpointName()));
    }
    @Override
    public void onEndpointLost(String id) {
      notifyListeners("endpointLost", obj(id, null));
    }
  };

  // ---- API -------------------------------------------------------------------
  @PluginMethod
  public void startAdvertising(PluginCall call) {
    String name = call.getString("name", "Hero");
    client.startAdvertising(name, SERVICE_ID, lifecycleCb,
        new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build())
      .addOnSuccessListener(v -> call.resolve())
      .addOnFailureListener(e -> call.reject("Could not host: " + e.getMessage()));
  }

  @PluginMethod
  public void startDiscovery(PluginCall call) {
    client.startDiscovery(SERVICE_ID, discoveryCb,
        new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build())
      .addOnSuccessListener(v -> call.resolve())
      .addOnFailureListener(e -> call.reject("Could not search: " + e.getMessage()));
  }

  @PluginMethod
  public void connect(PluginCall call) {
    String id = call.getString("endpointId");
    String name = call.getString("name", "Hero");
    client.stopDiscovery();
    client.requestConnection(name, id, lifecycleCb)
      .addOnSuccessListener(v -> call.resolve())
      .addOnFailureListener(e -> call.reject("Could not connect: " + e.getMessage()));
  }

  @PluginMethod
  public void send(PluginCall call) {
    String id = call.getString("endpointId");
    String data = call.getString("data", "");
    client.sendPayload(id, Payload.fromBytes(data.getBytes(StandardCharsets.UTF_8)))
      .addOnSuccessListener(v -> call.resolve())
      .addOnFailureListener(e -> call.reject(e.getMessage()));
  }

  @PluginMethod
  public void broadcast(PluginCall call) {
    if (connected.isEmpty()) { call.resolve(); return; }
    String data = call.getString("data", "");
    client.sendPayload(new ArrayList<>(connected), Payload.fromBytes(data.getBytes(StandardCharsets.UTF_8)))
      .addOnSuccessListener(v -> call.resolve())
      .addOnFailureListener(e -> call.reject(e.getMessage()));
  }

  @PluginMethod
  public void disconnect(PluginCall call) {
    String id = call.getString("endpointId");
    client.disconnectFromEndpoint(id);
    connected.remove(id);
    call.resolve();
  }

  @PluginMethod
  public void stopAll(PluginCall call) {
    client.stopAdvertising();
    client.stopDiscovery();
    client.stopAllEndpoints();
    connected.clear();
    names.clear();
    call.resolve();
  }
}
