import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene';
import { MenuScene } from './scenes/MenuScene';
import { ClassSelectScene } from './scenes/ClassSelectScene';
import { LobbyScene } from './scenes/LobbyScene';
import { GameScene } from './scenes/GameScene';
import { HudScene } from './scenes/HudScene';

export const VIEW = { w: 960, h: 540 } as const; // landscape; Scale.FIT letterboxes any phone

const isMobile =
  (navigator.maxTouchPoints > 0 && matchMedia('(pointer: coarse)').matches) ||
  /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
// Mobile only. Developers can test on desktop with ?desktop in the dev server URL (never in production builds).
const devDesktop = import.meta.env.DEV && new URLSearchParams(location.search).has('desktop');

function enterImmersive(): void {
  // Needs a user gesture; each call is best-effort because iOS Safari supports little of this.
  document.documentElement.requestFullscreen?.().catch(() => {});
  (screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> }).lock?.('landscape').catch(() => {});
  (navigator as Navigator & { wakeLock?: { request: (t: string) => Promise<unknown> } }).wakeLock?.request('screen').catch(() => {});
}

if (!isMobile && !devDesktop) {
  document.getElementById('blocker')?.classList.add('show');
} else {
  document.getElementById('rotate')?.classList.add('armed');
  document.addEventListener('pointerdown', enterImmersive, { once: true });
  document.addEventListener('contextmenu', (e) => e.preventDefault()); // no long-press menu mid-fight
  document.addEventListener('visibilitychange', () => { if (!document.hidden) enterImmersive(); });
  startGame();
}

function startGame(): void {
new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  width: VIEW.w,
  height: VIEW.h,
  backgroundColor: '#0b0d12',
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  input: { activePointers: 3 }, // joystick + two ability taps at once
  fps: { target: 60 },
  scene: [BootScene, MenuScene, ClassSelectScene, LobbyScene, GameScene, HudScene],
});
}
