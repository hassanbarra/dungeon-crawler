# How to play together (no internet)

## 1. Build the APK once (on a computer)
Install **Node 18+**, **JDK 17** and **Android Studio** (open it once so it installs the SDK). Then:
- Mac/Linux: `bash build-apk.sh`
- Windows: double-click `build-apk.bat`

Result: `apk/DungeonCrawler.apk` (debug build, first build takes several minutes).

## 2. Install on every phone
Copy the APK to each phone (USB, Bluetooth, Nearby Share), open it, allow "Install unknown apps".
Phones need **Android 6+**, **Google Play services**, and Bluetooth + Wi-Fi switched on.

## 3. Play
1. Everyone opens the game and picks a class.
2. **Host phone:** Menu → **Host Game**. Allow the Nearby/Bluetooth permission prompt.
3. **Other phones:** Menu → **Join Game**, allow permissions, tap the host's game in the list.
4. Everyone taps **Ready**; the run starts when all are ready.

Tips: stay within a few metres; the host should keep the app open and plugged in if possible (it does all the work); a phone with a weaker battery or CPU should join, not host.

## Troubleshooting
- Host not showing up: check Bluetooth and Wi-Fi are on, permissions granted, and both phones are updated in Google Play services.
- "Permission denied": Settings → Apps → Dungeon Crawler → Permissions → allow Nearby devices / Location.
- Build error in `NearbyPlugin.java`: send me the message and I'll fix it.
