"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CLASS_IDS = exports.CLASSES = void 0;
exports.CLASSES = {
    warrior: {
        id: 'warrior', name: 'Warrior', role: 'tank', color: 0x9aa7b8,
        blurb: 'Frontline bruiser. Soaks damage and controls space.',
        stats: { maxHp: 160, speed: 150, power: 1.0, defense: 4 },
        abilities: [
            { id: 'cleave', name: 'Cleave', kind: 'cone', cooldownMs: 600, damage: 22, range: 95, radius: 0, arcDeg: 110 },
            { id: 'charge', name: 'Charge', kind: 'dash', cooldownMs: 4000, damage: 0, range: 190, radius: 0, arcDeg: 0 },
            { id: 'slam', name: 'Ground Slam', kind: 'circle', cooldownMs: 6000, damage: 32, range: 0, radius: 115, arcDeg: 0 },
        ],
    },
    mage: {
        id: 'mage', name: 'Mage', role: 'dps', color: 0x6fa8ff,
        blurb: 'Glass cannon with long-range burst and area control.',
        stats: { maxHp: 90, speed: 140, power: 1.2, defense: 0 },
        abilities: [
            { id: 'firebolt', name: 'Firebolt', kind: 'ray', cooldownMs: 700, damage: 24, range: 420, radius: 14, arcDeg: 0 },
            { id: 'nova', name: 'Frost Nova', kind: 'circle', cooldownMs: 5000, damage: 14, range: 0, radius: 130, arcDeg: 0 },
            { id: 'meteor', name: 'Meteor', kind: 'circle', cooldownMs: 9000, damage: 55, range: 320, radius: 100, arcDeg: 0 },
        ],
    },
    rogue: {
        id: 'rogue', name: 'Rogue', role: 'dps', color: 0x7fd18b,
        blurb: 'Fast skirmisher. Strikes up close, repositions constantly.',
        stats: { maxHp: 110, speed: 185, power: 1.1, defense: 1 },
        abilities: [
            { id: 'flurry', name: 'Dagger Flurry', kind: 'cone', cooldownMs: 350, damage: 12, range: 65, radius: 0, arcDeg: 75 },
            { id: 'step', name: 'Shadow Step', kind: 'dash', cooldownMs: 3500, damage: 0, range: 230, radius: 0, arcDeg: 0 },
            { id: 'knife', name: 'Throwing Knife', kind: 'ray', cooldownMs: 900, damage: 18, range: 380, radius: 8, arcDeg: 0 },
        ],
    },
};
exports.CLASS_IDS = Object.keys(exports.CLASSES);
