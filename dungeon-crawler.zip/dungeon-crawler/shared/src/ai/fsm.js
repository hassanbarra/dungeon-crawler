"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateMachine = void 0;
class StateMachine {
    owner;
    states = new Map();
    current = null;
    constructor(owner) {
        this.owner = owner;
    }
    get currentName() { return this.current?.name ?? 'none'; }
    add(state) { this.states.set(state.name, state); return this; }
    start(name) { this.go(name); }
    go(name) {
        const next = this.states.get(name);
        if (!next)
            throw new Error(`Unknown state: ${name}`);
        this.current?.exit?.(this.owner);
        this.current = next;
        next.enter?.(this.owner);
    }
    update(dtMs) {
        if (!this.current)
            return;
        const next = this.current.update(this.owner, dtMs);
        if (next && next !== this.current.name)
            this.go(next);
    }
}
exports.StateMachine = StateMachine;
