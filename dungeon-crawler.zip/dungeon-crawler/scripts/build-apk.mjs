// Cross-platform APK builder. Run via build-apk.sh / build-apk.bat (or: node scripts/build-apk.mjs)
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const client = path.join(root, 'client');
const android = path.join(client, 'android');
const win = process.platform === 'win32';

const say = (m) => console.log(`\n==> ${m}`);
const die = (m) => { console.error(`\nERROR: ${m}`); process.exit(1); };
const run = (cmd, cwd) => {
  const r = spawnSync(cmd, { cwd, stdio: 'inherit', shell: true });
  if (r.status !== 0) die(`Command failed: ${cmd}`);
};
const has = (cmd) => spawnSync(`${cmd} -version`, { shell: true, stdio: 'ignore' }).status === 0
  || spawnSync(`${cmd} --version`, { shell: true, stdio: 'ignore' }).status === 0;

// ---- prerequisites ----------------------------------------------------------
if (!has('node')) die('Node.js 18+ is required: https://nodejs.org');
if (!has('java')) die('JDK 17 is required: https://adoptium.net');
const candidates = [
  process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT,
  path.join(os.homedir(), 'Android', 'Sdk'),
  path.join(os.homedir(), 'Library', 'Android', 'sdk'),
  process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Android', 'Sdk'),
].filter(Boolean);
const sdk = candidates.find((p) => fs.existsSync(p));
if (!sdk) die('Android SDK not found. Install Android Studio (https://developer.android.com/studio), open it once, then re-run.');

// ---- build web + android project --------------------------------------------
say('Installing dependencies'); run('npm install', root);
say('Building the game'); run('npm run build -w client', root);
if (!fs.existsSync(android)) { say('Creating Android project'); run('npx cap add android', client); }

say('Adding Bluetooth / Wi-Fi multiplayer to the Android project');
patchAndroid();
fs.writeFileSync(path.join(android, 'local.properties'), `sdk.dir=${sdk.replace(/\\/g, '/')}\n`);

say('Building APK (first run downloads Gradle: several minutes)');
run('npx cap sync android', client);
run(win ? 'gradlew.bat assembleDebug' : 'chmod +x gradlew && ./gradlew assembleDebug', android);

const out = path.join(root, 'apk');
fs.mkdirSync(out, { recursive: true });
fs.copyFileSync(path.join(android, 'app/build/outputs/apk/debug/app-debug.apk'), path.join(out, 'DungeonCrawler.apk'));
say(`Done: ${path.join(out, 'DungeonCrawler.apk')}`);
console.log('Copy it to every phone, open it, and allow "Install unknown apps". One phone taps Host Game; the others tap Join Game.');

// ---- patching ---------------------------------------------------------------
function patchAndroid() {
  const cfg = fs.readFileSync(path.join(client, 'capacitor.config.ts'), 'utf8');
  const appId = /appId:\s*'([^']+)'/.exec(cfg)?.[1];
  if (!appId) die('appId not found in capacitor.config.ts');

  const javaDir = path.join(android, 'app/src/main/java', ...appId.split('.'));
  fs.mkdirSync(javaDir, { recursive: true });
  const plugin = fs.readFileSync(path.join(client, 'native/android/NearbyPlugin.java'), 'utf8').replace(/__PACKAGE__/g, appId);
  fs.writeFileSync(path.join(javaDir, 'NearbyPlugin.java'), plugin);
  fs.writeFileSync(path.join(javaDir, 'MainActivity.java'), `package ${appId};

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(NearbyPlugin.class);
    super.onCreate(savedInstanceState);
    // The host phone runs the whole game: never let the screen sleep.
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  }
}
`);

  // manifest: permissions + landscape
  const mp = path.join(android, 'app/src/main/AndroidManifest.xml');
  let m = fs.readFileSync(mp, 'utf8');
  if (!m.includes('NEARBY_WIFI_DEVICES')) {
    const perms = `
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="28" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="31" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
    <uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES" android:usesPermissionFlags="neverForLocation" />
    `;
    m = m.replace('<application', `${perms}<application`);
  }
  if (!m.includes('sensorLandscape')) m = m.replace('<activity ', '<activity android:screenOrientation="sensorLandscape" ');
  fs.writeFileSync(mp, m);

  // gradle: Nearby dependency, minSdk 23
  const gp = path.join(android, 'app/build.gradle');
  let g = fs.readFileSync(gp, 'utf8');
  if (!g.includes('play-services-nearby')) {
    g = g.replace(/dependencies\s*\{/, "dependencies {\n    implementation 'com.google.android.gms:play-services-nearby:19.1.0'");
    fs.writeFileSync(gp, g);
  }
  const vp = path.join(android, 'variables.gradle');
  if (fs.existsSync(vp)) {
    fs.writeFileSync(vp, fs.readFileSync(vp, 'utf8').replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 23'));
  }
}
