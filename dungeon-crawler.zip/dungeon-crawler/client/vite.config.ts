import { defineConfig } from 'vite';

export default defineConfig({
  server: { host: true, fs: { allow: ['..'] } }, // host:true lets a phone on your LAN open the dev build
  build: { target: 'es2022', chunkSizeWarningLimit: 1500 },
});
