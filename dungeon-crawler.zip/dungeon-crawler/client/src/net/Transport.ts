import type { ClientMsg, ServerMsg } from '../../../shared/src/protocol';

export interface HostInfo { id: string; name: string }

/** Host phone side: advertises itself and talks to up to 3 joiners. */
export interface HostTransport {
  start(hostName: string): Promise<void>;
  stop(): Promise<void>;
  onPeer(cb: (peerId: string, name: string, connected: boolean) => void): void;
  onMessage(cb: (peerId: string, msg: ClientMsg) => void): void;
  sendTo(peerId: string, msg: ServerMsg): void;
  broadcast(msg: ServerMsg): void;
  kick(peerId: string): void;
}

/** Joiner phone side: finds hosts nearby and connects to one. */
export interface ClientTransport {
  discover(cb: (hosts: HostInfo[]) => void): Promise<void>;
  stopDiscover(): Promise<void>;
  connect(hostId: string, myName: string): Promise<void>;
  send(msg: ClientMsg): void;
  onMessage(cb: (msg: ServerMsg) => void): void;
  onClose(cb: () => void): void;
  close(): Promise<void>;
}

export interface TransportFactory {
  label: string; // shown in the UI, e.g. "Bluetooth / Wi-Fi"
  host(): HostTransport;
  client(): ClientTransport;
}
