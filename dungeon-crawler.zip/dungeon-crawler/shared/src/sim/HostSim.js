"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HostSim = void 0;
const protocol_1 = require("../protocol");
const classes_1 = require("../classes");
const enemies_1 = require("../enemies");
const geometry_1 = require("../geometry");
const Minion_1 = require("../ai/Minion");
const Boss_1 = require("../ai/Boss");
const MAX_INPUTS_PER_TICK = 3; // a modified phone can't out-run the host
const CORPSE_MS = 800;
const NEXT_ROOM_MS = 2000;
/** The whole game rules. Pure TypeScript: runs on the HOST phone, no server involved. */
class HostSim {
    hooks;
    phase = 'lobby';
    roomIndex = 0;
    players = new Map();
    inputs = new Map();
    cooldowns = new Map();
    enemies = new Map();
    deadAt = new Map();
    nextId = 0;
    now = 0; // simulation clock in ms (deterministic, testable)
    advanceAt = null;
    constructor(hooks) {
        this.hooks = hooks;
    }
    // ---- membership ---------------------------------------------------------
    addPlayer(id, name) {
        if (this.phase !== 'lobby' || this.players.size >= protocol_1.MAX_PLAYERS || this.players.has(id))
            return false;
        const def = classes_1.CLASSES.warrior;
        this.players.set(id, {
            id, name: name.slice(0, 14) || 'Hero', classId: def.id, ready: false, alive: true,
            x: 200, y: protocol_1.ARENA.h / 2 + (this.players.size - 1.5) * 50,
            hp: def.stats.maxHp, maxHp: def.stats.maxHp, lastSeq: 0,
        });
        this.inputs.set(id, []);
        this.cooldowns.set(id, [0, 0, 0]);
        return true;
    }
    removePlayer(id) {
        this.players.delete(id);
        this.inputs.delete(id);
        this.cooldowns.delete(id);
        if (this.phase === 'lobby')
            this.maybeStart();
        else
            this.checkDefeat();
    }
    // ---- messages from players (untrusted: validate everything) -------------
    handle(id, msg) {
        const p = this.players.get(id);
        if (!p || typeof msg !== 'object' || msg === null)
            return;
        switch (msg.t) {
            case 'class': {
                const def = classes_1.CLASSES[msg.classId];
                if (!def || this.phase !== 'lobby')
                    return;
                p.classId = def.id;
                p.maxHp = p.hp = def.stats.maxHp;
                break;
            }
            case 'ready':
                if (this.phase !== 'lobby')
                    return;
                p.ready = msg.ready === true;
                this.maybeStart();
                break;
            case 'input': {
                const q = this.inputs.get(id);
                if (q && q.length < 10 && Number.isFinite(msg.dx) && Number.isFinite(msg.dy) && Number.isFinite(msg.seq)) {
                    q.push({ seq: msg.seq, dx: msg.dx, dy: msg.dy });
                }
                break;
            }
            case 'ability':
                this.cast(p, msg.slot, msg.angle);
                break;
        }
    }
    // ---- run flow -----------------------------------------------------------
    maybeStart() {
        const ps = [...this.players.values()];
        if (ps.length > 0 && ps.every((p) => p.ready)) {
            this.phase = 'playing';
            this.roomIndex = 0;
            this.spawnEncounter();
        }
    }
    scale() { return { players: Math.max(1, this.players.size), floor: this.roomIndex + 1 }; }
    newId() { return `e${this.nextId++}`; }
    spawnEncounter() {
        const step = enemies_1.RUN_SCRIPT[this.roomIndex];
        if ('boss' in step) {
            this.enemies.set('boss', new Boss_1.Boss('boss', enemies_1.BOSSES[step.boss], protocol_1.ARENA.w - 300, protocol_1.ARENA.h / 2, this.scale()));
            return;
        }
        let i = 0;
        for (const [kind, n] of Object.entries(step.minions)) {
            for (let k = 0; k < n; k++, i++) {
                const a = (i / 8) * Math.PI * 2;
                const x = (0, protocol_1.clamp)(protocol_1.ARENA.w * 0.7 + Math.cos(a) * 220, 40, protocol_1.ARENA.w - 40);
                const y = (0, protocol_1.clamp)(protocol_1.ARENA.h / 2 + Math.sin(a) * 300, 40, protocol_1.ARENA.h - 40);
                const id = this.newId();
                this.enemies.set(id, new Minion_1.Minion(id, enemies_1.MINIONS[kind], x, y, this.scale()));
            }
        }
    }
    checkDefeat() {
        if (this.phase !== 'playing')
            return;
        const ps = [...this.players.values()];
        if (ps.length > 0 && ps.every((p) => !p.alive))
            this.phase = 'defeat';
    }
    // ---- simulation tick ----------------------------------------------------
    tick(dtMs) {
        this.now += dtMs;
        if (this.phase !== 'playing')
            return;
        for (const [id, p] of this.players) {
            const q = this.inputs.get(id);
            if (!q)
                continue;
            if (!p.alive) {
                q.length = 0;
                continue;
            }
            const speed = classes_1.CLASSES[p.classId].stats.speed;
            for (const input of q.splice(0, MAX_INPUTS_PER_TICK)) {
                const pos = (0, protocol_1.stepMovement)(p, input.dx, input.dy, speed, protocol_1.TICK_MS);
                p.x = pos.x;
                p.y = pos.y;
                p.lastSeq = input.seq;
            }
        }
        for (const e of [...this.enemies.values()]) {
            e.update(dtMs, this.world);
            if (e.dead) {
                const since = this.deadAt.get(e.id) ?? this.now;
                this.deadAt.set(e.id, since);
                if (this.now - since > CORPSE_MS) {
                    this.enemies.delete(e.id);
                    this.deadAt.delete(e.id);
                }
            }
        }
        this.checkDefeat();
        this.checkRoomCleared();
    }
    checkRoomCleared() {
        if (this.phase !== 'playing' || this.enemies.size > 0)
            return;
        if (this.roomIndex >= enemies_1.RUN_SCRIPT.length - 1) {
            this.phase = 'victory';
            return;
        }
        if (this.advanceAt === null) {
            this.advanceAt = this.now + NEXT_ROOM_MS;
            return;
        }
        if (this.now >= this.advanceAt) {
            this.advanceAt = null;
            this.roomIndex++;
            for (const p of this.players.values()) { // between rooms: revive + heal 30%
                p.alive = true;
                p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.3);
            }
            this.spawnEncounter();
        }
    }
    // ---- abilities ----------------------------------------------------------
    cast(p, slot, angle) {
        if (!p.alive || this.phase !== 'playing')
            return;
        if (slot !== 0 && slot !== 1 && slot !== 2)
            return;
        if (!Number.isFinite(angle))
            return;
        const cls = classes_1.CLASSES[p.classId];
        const ab = cls.abilities[slot];
        const cd = this.cooldowns.get(p.id);
        if (this.now < cd[slot])
            return;
        cd[slot] = this.now + ab.cooldownMs;
        const dmg = ab.damage * cls.stats.power;
        const live = [...this.enemies.values()].filter((e) => !e.dead);
        switch (ab.kind) {
            case 'cone':
                for (const e of live) {
                    if ((0, geometry_1.inCone)(p.x, p.y, angle, (ab.arcDeg * Math.PI) / 180, ab.range, e.x, e.y, e.def.radius))
                        e.takeDamage(dmg);
                }
                this.hooks.fx({ kind: 'hit', x: p.x, y: p.y, r: ab.range, ms: 150, angle, arc: ab.arcDeg });
                break;
            case 'circle': {
                const cx = p.x + Math.cos(angle) * ab.range;
                const cy = p.y + Math.sin(angle) * ab.range;
                for (const e of live)
                    if ((0, geometry_1.inCircle)(cx, cy, ab.radius, e.x, e.y, e.def.radius))
                        e.takeDamage(dmg);
                this.hooks.fx({ kind: 'hit', x: cx, y: cy, r: ab.radius, ms: 250 });
                break;
            }
            case 'ray': {
                const bx = p.x + Math.cos(angle) * ab.range;
                const by = p.y + Math.sin(angle) * ab.range;
                let best = null;
                let bestT = Infinity;
                for (const e of live) {
                    const { d, t } = (0, geometry_1.pointSegment)(p.x, p.y, bx, by, e.x, e.y);
                    if (d <= ab.radius + e.def.radius && t < bestT) {
                        best = e;
                        bestT = t;
                    }
                }
                best?.takeDamage(dmg);
                this.hooks.fx({ kind: 'dash', x: p.x, y: p.y, r: ab.range * (best ? bestT : 1), ms: 120, angle });
                break;
            }
            case 'dash':
                p.x = (0, protocol_1.clamp)(p.x + Math.cos(angle) * ab.range, 16, protocol_1.ARENA.w - 16);
                p.y = (0, protocol_1.clamp)(p.y + Math.sin(angle) * ab.range, 16, protocol_1.ARENA.h - 16);
                break;
        }
    }
    // ---- AI's view of the world --------------------------------------------
    hurtPlayers(test, amount) {
        for (const p of this.players.values()) {
            if (!p.alive || !test(p))
                continue;
            const def = classes_1.CLASSES[p.classId].stats.defense;
            p.hp = Math.max(0, p.hp - Math.max(1, amount - def));
            if (p.hp <= 0)
                p.alive = false;
        }
    }
    world = {
        players: () => [...this.players.values()].filter((p) => p.alive).map((p) => ({ id: p.id, x: p.x, y: p.y })),
        damageCircle: (x, y, r, amount) => this.hurtPlayers((p) => (0, geometry_1.inCircle)(x, y, r, p.x, p.y, 12), amount),
        damageCone: (x, y, facing, arcDeg, range, amount) => this.hurtPlayers((p) => (0, geometry_1.inCone)(x, y, facing, (arcDeg * Math.PI) / 180, range, p.x, p.y, 12), amount),
        spawnMinion: (kind, x, y) => {
            const def = enemies_1.MINIONS[kind];
            if (!def)
                return;
            const id = this.newId();
            this.enemies.set(id, new Minion_1.Minion(id, def, x, y, this.scale()));
        },
        fx: (msg) => this.hooks.fx(msg),
    };
    // ---- replication --------------------------------------------------------
    snapshot() {
        const enemies = [...this.enemies.values()].map((e) => ({
            id: e.id, kind: e.def.id, isBoss: e instanceof Boss_1.Boss, ai: e.stateName, phase: e.phase,
            x: e.x, y: e.y, hp: e.hp, maxHp: e.maxHp, radius: e.def.radius, invulnerable: e.invulnerable,
        }));
        return { t: 'snap', phase: this.phase, roomIndex: this.roomIndex, players: [...this.players.values()].map((p) => ({ ...p })), enemies };
    }
}
exports.HostSim = HostSim;
