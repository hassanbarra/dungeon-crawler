"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dist = dist;
exports.inCircle = inCircle;
exports.angleDiff = angleDiff;
exports.inCone = inCone;
exports.pointSegment = pointSegment;
function dist(ax, ay, bx, by) {
    return Math.hypot(bx - ax, by - ay);
}
function inCircle(cx, cy, r, px, py, pad = 0) {
    return dist(cx, cy, px, py) <= r + pad;
}
function angleDiff(a, b) {
    let d = a - b;
    while (d > Math.PI)
        d -= Math.PI * 2;
    while (d < -Math.PI)
        d += Math.PI * 2;
    return Math.abs(d);
}
function inCone(ox, oy, facing, arcRad, range, px, py, pad = 0) {
    if (dist(ox, oy, px, py) > range + pad)
        return false;
    return angleDiff(Math.atan2(py - oy, px - ox), facing) <= arcRad / 2;
}
/** Distance from point to segment, plus normalized position t along it. */
function pointSegment(ax, ay, bx, by, px, py) {
    const vx = bx - ax, vy = by - ay;
    const len2 = vx * vx + vy * vy || 1;
    const t = Math.max(0, Math.min(1, ((px - ax) * vx + (py - ay) * vy) / len2));
    return { d: dist(px, py, ax + vx * t, ay + vy * t), t };
}
