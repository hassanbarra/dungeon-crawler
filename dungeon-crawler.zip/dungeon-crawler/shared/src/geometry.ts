export function dist(ax: number, ay: number, bx: number, by: number): number {
  return Math.hypot(bx - ax, by - ay);
}

export function inCircle(cx: number, cy: number, r: number, px: number, py: number, pad = 0): boolean {
  return dist(cx, cy, px, py) <= r + pad;
}

export function angleDiff(a: number, b: number): number {
  let d = a - b;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return Math.abs(d);
}

export function inCone(ox: number, oy: number, facing: number, arcRad: number, range: number, px: number, py: number, pad = 0): boolean {
  if (dist(ox, oy, px, py) > range + pad) return false;
  return angleDiff(Math.atan2(py - oy, px - ox), facing) <= arcRad / 2;
}

/** Distance from point to segment, plus normalized position t along it. */
export function pointSegment(ax: number, ay: number, bx: number, by: number, px: number, py: number): { d: number; t: number } {
  const vx = bx - ax, vy = by - ay;
  const len2 = vx * vx + vy * vy || 1;
  const t = Math.max(0, Math.min(1, ((px - ax) * vx + (py - ay) * vy) / len2));
  return { d: dist(px, py, ax + vx * t, ay + vy * t), t };
}
