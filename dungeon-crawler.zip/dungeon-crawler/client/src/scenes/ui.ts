import Phaser from 'phaser';

export function label(scene: Phaser.Scene, x: number, y: number, s: string, size = 20, color = '#e8e6df'): Phaser.GameObjects.Text {
  return scene.add.text(x, y, s, { fontFamily: 'system-ui, sans-serif', fontSize: `${size}px`, color }).setOrigin(0.5);
}

/** Big touch-friendly button (minimum 48px tall in game units). */
export function button(scene: Phaser.Scene, x: number, y: number, w: number, text: string, onTap: () => void, h = 56): Phaser.GameObjects.Container {
  const bg = scene.add.rectangle(0, 0, w, h, 0x2a3142).setStrokeStyle(2, 0x6b7a99);
  const t = label(scene, 0, 0, text, 22);
  const c = scene.add.container(x, y, [bg, t]).setSize(w, h).setInteractive({ useHandCursor: true });
  c.on('pointerdown', () => bg.setFillStyle(0x3b4660));
  c.on('pointerout', () => bg.setFillStyle(0x2a3142));
  c.on('pointerup', () => { bg.setFillStyle(0x2a3142); onTap(); });
  return c;
}
