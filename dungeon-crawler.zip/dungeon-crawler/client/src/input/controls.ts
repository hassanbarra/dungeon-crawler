/** Written by the HUD (touch or keyboard), read by the game scene every frame. */
export const controls = { x: 0, y: 0 };
