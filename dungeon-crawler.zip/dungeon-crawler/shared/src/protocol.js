"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_PLAYERS = exports.ARENA = exports.TICK_MS = exports.TICK_RATE = void 0;
exports.stepMovement = stepMovement;
exports.clamp = clamp;
exports.TICK_RATE = 20;
exports.TICK_MS = 1000 / exports.TICK_RATE;
exports.ARENA = { w: 1600, h: 1200 };
exports.MAX_PLAYERS = 4; // host + 3 friends
/** Shared by host (authoritative) and every client (prediction). Must stay deterministic. */
function stepMovement(pos, dx, dy, speed, dtMs) {
    const len = Math.hypot(dx, dy);
    if (len < 0.01)
        return { x: pos.x, y: pos.y };
    const k = Math.min(1, len) / len;
    const step = (speed * dtMs) / 1000;
    return {
        x: clamp(pos.x + dx * k * step, 16, exports.ARENA.w - 16),
        y: clamp(pos.y + dy * k * step, 16, exports.ARENA.h - 16),
    };
}
function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
}
