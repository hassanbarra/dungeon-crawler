import Phaser from 'phaser';
import { Current } from '../net/Session';
import { controls } from '../input/controls';
import { VirtualJoystick } from '../input/VirtualJoystick';
import { CLASSES, ClassId } from '../../../shared/src/classes';
import { button, label } from './ui';

const SLOTS = [
  { x: 850, y: 445, r: 46 },
  { x: 740, y: 480, r: 34 },
  { x: 790, y: 370, r: 34 },
] as const;

export class HudScene extends Phaser.Scene {
  private joy!: VirtualJoystick;
  private cdEnd = [0, 0, 0];
  private cdGfx!: Phaser.GameObjects.Graphics;
  private hud!: Phaser.GameObjects.Graphics;
  private banner!: Phaser.GameObjects.Text;
  private bossName!: Phaser.GameObjects.Text;
  private ended = false;

  constructor() { super('Hud'); }

  create(): void {
    this.ended = false;
    this.cdEnd = [0, 0, 0];
    this.input.addPointer(2);
    this.joy = new VirtualJoystick(this);
    this.cdGfx = this.add.graphics().setDepth(50);
    this.hud = this.add.graphics().setDepth(50);
    this.banner = label(this, this.scale.width / 2, 200, '', 56, '#e0a030').setDepth(60);
    this.bossName = label(this, this.scale.width / 2, 22, '', 16, '#e0a030');

    const v = Current.session!.view;
    const me = v.players.get(v.myId);
    const cls = CLASSES[(me?.classId ?? 'warrior') as ClassId];

    SLOTS.forEach((s, i) => {
      const circle = this.add.circle(s.x, s.y, s.r, 0x2a3142, 0.85).setStrokeStyle(3, 0x8ea0c4).setInteractive();
      label(this, s.x, s.y, cls.abilities[i].name.split(' ').map((w) => w[0]).join(''), s.r * 0.6).setDepth(51);
      circle.on('pointerdown', () => this.fire(i as 0 | 1 | 2));
    });

  }

  private fire(slot: 0 | 1 | 2): void {
    const v = Current.session?.view;
    const me = v?.players.get(v.myId);
    if (!me || !me.alive || this.time.now < this.cdEnd[slot]) return;
    this.cdEnd[slot] = this.time.now + CLASSES[me.classId as ClassId].abilities[slot].cooldownMs;
    navigator.vibrate?.(12); // light haptic tick on supported phones
    this.game.events.emit('ability', slot);
  }

  update(): void {
    const v = Current.session?.view;
    if (!v) return;
    const me = v.players.get(v.myId);

    controls.x = this.joy.vector.x;
    controls.y = this.joy.vector.y;

    // cooldown overlays
    const g = this.cdGfx;
    g.clear();
    SLOTS.forEach((s, i) => {
      const left = this.cdEnd[i] - this.time.now;
      if (left <= 0 || !me) return;
      const total = CLASSES[me.classId as ClassId].abilities[i].cooldownMs;
      g.fillStyle(0x000000, 0.6).slice(s.x, s.y, s.r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (left / total), false).fillPath();
    });

    // player HP + boss HP
    const h = this.hud;
    h.clear();
    if (me) {
      h.fillStyle(0x000000, 0.6).fillRect(16, 16, 220, 16);
      h.fillStyle(0x5ec26a).fillRect(16, 16, 220 * (me.hp / me.maxHp), 16);
    }
    let boss: { hp: number; maxHp: number } | null = null;
    v.enemies.forEach((e) => { if (e.isBoss && e.hp > 0) boss = e; });
    const b = boss as { hp: number; maxHp: number } | null;
    this.bossName.setText(b ? 'The Hollow Warden' : '');
    if (b) {
      h.fillStyle(0x000000, 0.6).fillRect(280, 40, 400, 14);
      h.fillStyle(0xe0a030).fillRect(280, 40, 400 * (b.hp / b.maxHp), 14);
    }

    // end of run
    const phase = v.phase;
    if (!this.ended && (phase === 'victory' || phase === 'defeat')) {
      this.ended = true;
      this.banner.setText(phase === 'victory' ? 'VICTORY' : 'DEFEATED').setColor(phase === 'victory' ? '#e0a030' : '#d4574f');
      button(this, this.scale.width / 2, 300, 280, 'Back to Menu', async () => {
        await Current.session?.leave();
        Current.session = null;
        this.scene.stop('Game');
        this.scene.start('Menu');
      }).setDepth(60);
    }
  }
}
