import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.dungeoncrawler', // change before publishing
  appName: 'Dungeon Crawler',
  webDir: 'dist',

};
export default config;
