export const TICK_RATE = 20;
export const TICK_MS = 1000 / TICK_RATE;
export const ARENA = { w: 1600, h: 1200 } as const;
export const MAX_PLAYERS = 4; // host + 3 friends

export type Phase = 'lobby' | 'playing' | 'victory' | 'defeat';

/** One input = one 50 ms tick of intent. seq lets the client reconcile prediction. */
export interface InputMsg { seq: number; dx: number; dy: number }
export interface FxMsg { kind: 'hit' | 'telegraph' | 'phase' | 'dash'; x: number; y: number; r: number; ms: number; angle?: number; arc?: number }

export interface PlayerState {
  id: string; name: string; classId: string;
  ready: boolean; alive: boolean;
  x: number; y: number; hp: number; maxHp: number;
  lastSeq: number;
}
export interface EnemyView {
  id: string; kind: string; isBoss: boolean; ai: string; phase: number;
  x: number; y: number; hp: number; maxHp: number; radius: number; invulnerable: boolean;
}
export interface Snapshot { t: 'snap'; phase: Phase; roomIndex: number; players: PlayerState[]; enemies: EnemyView[] }

/** Wire protocol: JSON strings over Bluetooth / Wi-Fi Direct (Nearby) or BroadcastChannel (dev). */
export type ClientMsg =
  | { t: 'class'; classId: string }
  | { t: 'ready'; ready: boolean }
  | ({ t: 'input' } & InputMsg)
  | { t: 'ability'; slot: 0 | 1 | 2; angle: number };

export type ServerMsg =
  | Snapshot
  | { t: 'fx'; fx: FxMsg }
  | { t: 'welcome'; id: string };

export interface Vec2 { x: number; y: number }

/** Shared by host (authoritative) and every client (prediction). Must stay deterministic. */
export function stepMovement(pos: Vec2, dx: number, dy: number, speed: number, dtMs: number): Vec2 {
  const len = Math.hypot(dx, dy);
  if (len < 0.01) return { x: pos.x, y: pos.y };
  const k = Math.min(1, len) / len;
  const step = (speed * dtMs) / 1000;
  return {
    x: clamp(pos.x + dx * k * step, 16, ARENA.w - 16),
    y: clamp(pos.y + dy * k * step, 16, ARENA.h - 16),
  };
}

export function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}
