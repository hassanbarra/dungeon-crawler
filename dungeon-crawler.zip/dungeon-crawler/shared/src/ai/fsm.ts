export interface State<O> {
  name: string;
  enter?(owner: O): void;
  /** Return another state's name to transition. */
  update(owner: O, dtMs: number): string | void;
  exit?(owner: O): void;
}

export class StateMachine<O> {
  private states = new Map<string, State<O>>();
  private current: State<O> | null = null;

  constructor(private owner: O) {}

  get currentName(): string { return this.current?.name ?? 'none'; }

  add(state: State<O>): this { this.states.set(state.name, state); return this; }

  start(name: string): void { this.go(name); }

  go(name: string): void {
    const next = this.states.get(name);
    if (!next) throw new Error(`Unknown state: ${name}`);
    this.current?.exit?.(this.owner);
    this.current = next;
    next.enter?.(this.owner);
  }

  update(dtMs: number): void {
    if (!this.current) return;
    const next = this.current.update(this.owner, dtMs);
    if (next && next !== this.current.name) this.go(next);
  }
}
