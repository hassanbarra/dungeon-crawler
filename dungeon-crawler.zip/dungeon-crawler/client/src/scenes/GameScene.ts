import Phaser from 'phaser';
import { Current, GameView, Session } from '../net/Session';
import { controls } from '../input/controls';
import { ARENA, FxMsg, InputMsg, TICK_MS, Vec2, stepMovement } from '../../../shared/src/protocol';
import { CLASSES, ClassId } from '../../../shared/src/classes';
import { MINIONS, BOSSES } from '../../../shared/src/enemies';

interface LiveFx extends FxMsg { born: number }

export class GameScene extends Phaser.Scene {
  private session!: Session;
  private v!: GameView;
  private sprites = new Map<string, Phaser.GameObjects.Image>();
  private bars!: Phaser.GameObjects.Graphics;
  private fxGfx!: Phaser.GameObjects.Graphics;
  private fx: LiveFx[] = [];
  private pending: InputMsg[] = [];
  private seq = 0;
  private acc = 0;
  private idleSent = false;
  private facing = 0;
  private following = false;

  constructor() { super('Game'); }

  create(): void {
    this.session = Current.session!;
    this.v = this.session.view;
    this.sprites.clear(); this.fx = []; this.pending = []; this.seq = 0; this.following = false;

    this.add.tileSprite(0, 0, ARENA.w, ARENA.h, 'floor').setOrigin(0);
    this.add.rectangle(0, 0, ARENA.w, ARENA.h).setOrigin(0).setStrokeStyle(6, 0x4a3b24);
    this.fxGfx = this.add.graphics().setDepth(5);
    this.bars = this.add.graphics().setDepth(10);
    this.cameras.main.setBounds(0, 0, ARENA.w, ARENA.h);

    this.session.onFx((m: FxMsg) => this.fx.push({ ...m, born: this.time.now }));
    this.session.onClose(() => this.scene.start('Menu')); // host disconnected
    this.game.events.on('ability', this.onAbility, this);
    this.scene.launch('Hud');
    this.events.once('shutdown', () => { this.game.events.off('ability', this.onAbility, this); this.scene.stop('Hud'); });
  }

  // ---- input -> server ----------------------------------------------------
  private onAbility(slot: 0 | 1 | 2): void {
    let best: { x: number; y: number } | null = null;
    let bestD = 520;
    const me = this.v.players.get(this.v.myId);
    if (!me) return;
    this.v.enemies.forEach((e) => {
      const d = Phaser.Math.Distance.Between(me.x, me.y, e.x, e.y);
      if (e.hp > 0 && d < bestD) { best = e; bestD = d; }
    });
    // Mobile aiming: auto-target nearest enemy, otherwise fire the way you're walking.
    const t = best as { x: number; y: number } | null;
    const angle = t ? Math.atan2(t.y - me.y, t.x - me.x) : this.facing;
    this.session.send({ t: 'ability', slot, angle });
  }

  update(_time: number, dtMs: number): void {
    const me = this.v.players.get(this.v.myId);
    if (!me) return;

    // fixed 20 Hz input send + local prediction
    this.acc += dtMs;
    while (this.acc >= TICK_MS) {
      this.acc -= TICK_MS;
      const moving = Math.hypot(controls.x, controls.y) > 0.05;
      if (moving) {
        this.facing = Math.atan2(controls.y, controls.x);
        const input: InputMsg = { seq: ++this.seq, dx: controls.x, dy: controls.y };
        this.pending.push(input);
        this.session.send({ t: 'input', ...input });
        this.idleSent = false;
      } else if (!this.idleSent) {
        this.session.send({ t: 'input', seq: ++this.seq, dx: 0, dy: 0 });
        this.idleSent = true;
      }
    }

    // reconcile: start from the server's truth, replay inputs it hasn't seen yet
    this.pending = this.pending.filter((i) => i.seq > me.lastSeq);
    const speed = CLASSES[me.classId as ClassId].stats.speed;
    let pos: Vec2 = { x: me.x, y: me.y };
    for (const i of this.pending) pos = stepMovement(pos, i.dx, i.dy, speed, TICK_MS);

    this.syncSprites(me.id, pos);
    this.drawBars();
    this.drawFx();
  }

  // ---- rendering ----------------------------------------------------------
  private sprite(key: string, tint: number, radius: number): Phaser.GameObjects.Image {
    let s = this.sprites.get(key);
    if (!s) {
      s = this.add.image(0, 0, 'dot').setTint(tint).setScale(radius / 16).setDepth(2);
      this.sprites.set(key, s);
    }
    return s;
  }

  private syncSprites(myId: string, myPos: Vec2): void {
    const alive = new Set<string>();

    this.v.players.forEach((p) => {
      const key = `p:${p.id}`;
      alive.add(key);
      const s = this.sprite(key, CLASSES[p.classId as ClassId].color, 16);
      const mine = p.id === myId;
      const tx = mine ? myPos.x : p.x, ty = mine ? myPos.y : p.y;
      const k = mine ? 0.5 : 0.25; // remote players: smooth toward 20 Hz snapshots
      s.setPosition(Phaser.Math.Linear(s.x || tx, tx, k), Phaser.Math.Linear(s.y || ty, ty, k));
      s.setAlpha(p.alive ? 1 : 0.3);
      if (mine && !this.following) { this.cameras.main.startFollow(s, true, 0.15, 0.15); this.following = true; }
    });

    this.v.enemies.forEach((e) => {
      const key = `e:${e.id}`;
      alive.add(key);
      const def = e.isBoss ? BOSSES.warden : MINIONS[e.kind];
      const s = this.sprite(key, def?.color ?? 0xff00ff, e.radius);
      s.setPosition(Phaser.Math.Linear(s.x || e.x, e.x, 0.3), Phaser.Math.Linear(s.y || e.y, e.y, 0.3));
      s.setAlpha(e.hp <= 0 ? 0.25 : e.invulnerable ? 0.5 + 0.3 * Math.sin(this.time.now / 60) : 1);
    });

    for (const [key, s] of this.sprites) if (!alive.has(key)) { s.destroy(); this.sprites.delete(key); }
  }

  private drawBars(): void {
    const g = this.bars;
    g.clear();
    const bar = (x: number, y: number, w: number, frac: number, color: number) => {
      g.fillStyle(0x000000, 0.6).fillRect(x - w / 2, y, w, 5);
      g.fillStyle(color).fillRect(x - w / 2, y, w * Math.max(0, frac), 5);
    };
    this.v.players.forEach((p) => { const s = this.sprites.get(`p:${p.id}`); if (s) bar(s.x, s.y - 28, 34, p.hp / p.maxHp, 0x5ec26a); });
    this.v.enemies.forEach((e) => { if (e.isBoss) return; const s = this.sprites.get(`e:${e.id}`); if (s) bar(s.x, s.y - e.radius - 12, 30, e.hp / e.maxHp, 0xd4574f); });
  }

  private drawFx(): void {
    const g = this.fxGfx;
    g.clear();
    this.fx = this.fx.filter((f) => this.time.now - f.born < f.ms);
    for (const f of this.fx) {
      const t = (this.time.now - f.born) / f.ms;
      if (f.kind === 'telegraph') { // red zone that fills as the hit lands: this is the player's dodge cue
        g.fillStyle(0xff3030, 0.12 + 0.25 * t).lineStyle(2, 0xff6060, 0.8);
        this.shape(g, f);
      } else if (f.kind === 'hit') {
        g.fillStyle(0xffffff, 0.5 * (1 - t));
        this.shape(g, f);
      } else if (f.kind === 'phase') {
        g.lineStyle(6, 0xe0a030, 1 - t).strokeCircle(f.x, f.y, f.r * t);
      } else if (f.kind === 'dash') {
        g.lineStyle(4, 0xbfe4ff, 1 - t).lineBetween(f.x, f.y, f.x + Math.cos(f.angle ?? 0) * f.r, f.y + Math.sin(f.angle ?? 0) * f.r);
      }
    }
  }

  private shape(g: Phaser.GameObjects.Graphics, f: FxMsg): void {
    if (f.arc && f.arc < 360) {
      const a = f.angle ?? 0, half = Phaser.Math.DegToRad(f.arc / 2);
      g.slice(f.x, f.y, f.r, a - half, a + half).fillPath();
    } else {
      g.fillCircle(f.x, f.y, f.r);
    }
  }
}
