import type { ClientMsg, ServerMsg } from '../../../shared/src/protocol';
import type { ClientTransport, HostInfo, HostTransport, TransportFactory } from './Transport';

/** DEV ONLY: simulates nearby phones with browser tabs (BroadcastChannel). Lets you test on a desktop. */
interface Packet {
  k: 'ad' | 'hello' | 'to-host' | 'to-client' | 'to-all' | 'bye' | 'kick' | 'host-bye';
  hostId?: string; clientId?: string; name?: string; msg?: ClientMsg | ServerMsg;
}
const uid = () => Math.random().toString(36).slice(2, 9);
const CHANNEL = 'dungeon-dev';

class TabHost implements HostTransport {
  private ch = new BroadcastChannel(CHANNEL);
  private id = uid();
  private timer = 0;
  private peerCb: (id: string, name: string, up: boolean) => void = () => {};
  private msgCb: (id: string, m: ClientMsg) => void = () => {};
  private post(p: Packet) { this.ch.postMessage(p); }

  onPeer(cb: (id: string, name: string, up: boolean) => void): void { this.peerCb = cb; }
  onMessage(cb: (id: string, m: ClientMsg) => void): void { this.msgCb = cb; }

  async start(name: string): Promise<void> {
    this.ch.onmessage = (e: MessageEvent<Packet>) => {
      const p = e.data;
      if (p.hostId !== this.id || !p.clientId) return;
      if (p.k === 'hello') this.peerCb(p.clientId, p.name ?? 'Hero', true);
      else if (p.k === 'bye') this.peerCb(p.clientId, '', false);
      else if (p.k === 'to-host' && p.msg) this.msgCb(p.clientId, p.msg as ClientMsg);
    };
    const ad = () => this.post({ k: 'ad', hostId: this.id, name: `${name}'s game` });
    ad();
    this.timer = window.setInterval(ad, 1000);
  }
  async stop(): Promise<void> { clearInterval(this.timer); this.post({ k: 'host-bye', hostId: this.id }); this.ch.close(); }
  sendTo(peerId: string, msg: ServerMsg): void { this.post({ k: 'to-client', hostId: this.id, clientId: peerId, msg }); }
  broadcast(msg: ServerMsg): void { this.post({ k: 'to-all', hostId: this.id, msg }); }
  kick(peerId: string): void { this.post({ k: 'kick', hostId: this.id, clientId: peerId }); }
}

class TabClient implements ClientTransport {
  private ch = new BroadcastChannel(CHANNEL);
  private id = uid();
  private hostId: string | null = null;
  private seen = new Map<string, { info: HostInfo; at: number }>();
  private timer = 0;
  private msgCb: (m: ServerMsg) => void = () => {};
  private closeCb: () => void = () => {};
  private post(p: Packet) { this.ch.postMessage(p); }

  onMessage(cb: (m: ServerMsg) => void): void { this.msgCb = cb; }
  onClose(cb: () => void): void { this.closeCb = cb; }

  async discover(cb: (hosts: HostInfo[]) => void): Promise<void> {
    const emit = () => cb([...this.seen.values()].map((s) => s.info));
    this.ch.onmessage = (e: MessageEvent<Packet>) => {
      const p = e.data;
      if (p.k === 'ad' && p.hostId) { this.seen.set(p.hostId, { info: { id: p.hostId, name: p.name ?? 'Game' }, at: Date.now() }); emit(); }
      else if (p.hostId === this.hostId && this.hostId) {
        if (p.k === 'to-all' && p.msg) this.msgCb(p.msg as ServerMsg);
        else if (p.k === 'to-client' && p.clientId === this.id && p.msg) this.msgCb(p.msg as ServerMsg);
        else if (p.k === 'host-bye' || (p.k === 'kick' && p.clientId === this.id)) this.closeCb();
      }
    };
    this.timer = window.setInterval(() => {
      for (const [k, s] of this.seen) if (Date.now() - s.at > 3000) this.seen.delete(k);
      emit();
    }, 1000);
  }
  async stopDiscover(): Promise<void> { clearInterval(this.timer); }
  async connect(hostId: string, myName: string): Promise<void> { this.hostId = hostId; this.post({ k: 'hello', hostId, clientId: this.id, name: myName }); }
  send(msg: ClientMsg): void { if (this.hostId) this.post({ k: 'to-host', hostId: this.hostId, clientId: this.id, msg }); }
  async close(): Promise<void> {
    if (this.hostId) this.post({ k: 'bye', hostId: this.hostId, clientId: this.id });
    clearInterval(this.timer); this.ch.close();
  }
}

export const tabTransport: TransportFactory = { label: 'Browser tabs (dev)', host: () => new TabHost(), client: () => new TabClient() };
