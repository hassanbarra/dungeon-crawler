"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Enemy = void 0;
const protocol_1 = require("../protocol");
const geometry_1 = require("../geometry");
const enemies_1 = require("../enemies");
const fsm_1 = require("./fsm");
class Enemy {
    id;
    def;
    x;
    y;
    hp;
    maxHp;
    damage;
    phase = 0;
    facing = 0;
    invulnerable = false;
    targetId = null;
    stateName = 'idle';
    world;
    fsm;
    constructor(id, def, x, y, scale) {
        this.id = id;
        this.def = def;
        this.x = x;
        this.y = y;
        this.maxHp = this.hp = (0, enemies_1.scaledHp)(def.hp, scale.players, scale.floor);
        this.damage = (0, enemies_1.scaledDamage)(def.damage, scale.floor);
        this.fsm = new fsm_1.StateMachine(this);
    }
    get dead() { return this.hp <= 0; }
    update(dtMs, world) {
        this.world = world;
        if (this.dead) {
            if (this.fsm.currentName !== 'dead')
                this.fsm.go('dead');
        }
        else {
            this.beforeUpdate();
            this.fsm.update(dtMs);
        }
        this.stateName = this.fsm.currentName;
    }
    /** Hook for subclasses (boss phase checks). */
    beforeUpdate() { }
    takeDamage(amount) {
        if (this.invulnerable || this.dead)
            return false;
        this.hp = Math.max(0, this.hp - amount);
        return true;
    }
    target() {
        return this.world.players().find((p) => p.id === this.targetId) ?? null;
    }
    nearestPlayer() {
        let best = null;
        let bestD = Infinity;
        for (const p of this.world.players()) {
            const d = (0, geometry_1.dist)(this.x, this.y, p.x, p.y);
            if (d < bestD) {
                best = p;
                bestD = d;
            }
        }
        return best;
    }
    distTo(t) { return (0, geometry_1.dist)(this.x, this.y, t.x, t.y); }
    moveToward(t, speedMul, dtMs) {
        this.facing = Math.atan2(t.y - this.y, t.x - this.x);
        const step = (this.def.speed * speedMul * dtMs) / 1000;
        this.x = (0, protocol_1.clamp)(this.x + Math.cos(this.facing) * step, 20, protocol_1.ARENA.w - 20);
        this.y = (0, protocol_1.clamp)(this.y + Math.sin(this.facing) * step, 20, protocol_1.ARENA.h - 20);
    }
}
exports.Enemy = Enemy;
