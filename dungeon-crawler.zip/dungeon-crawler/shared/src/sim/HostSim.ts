import {
  ARENA, ClientMsg, EnemyView, FxMsg, InputMsg, MAX_PLAYERS, Phase, PlayerState, Snapshot, TICK_MS, clamp, stepMovement,
} from '../protocol';
import { CLASSES, ClassId } from '../classes';
import { BOSSES, MINIONS, RUN_SCRIPT } from '../enemies';
import { inCircle, inCone, pointSegment } from '../geometry';
import { Enemy } from '../ai/Enemy';
import { Minion } from '../ai/Minion';
import { Boss } from '../ai/Boss';
import type { AIWorld } from '../ai/world';

const MAX_INPUTS_PER_TICK = 3; // a modified phone can't out-run the host
const CORPSE_MS = 800;
const NEXT_ROOM_MS = 2000;

export interface SimHooks { fx(msg: FxMsg): void }

/** The whole game rules. Pure TypeScript: runs on the HOST phone, no server involved. */
export class HostSim {
  phase: Phase = 'lobby';
  roomIndex = 0;
  readonly players = new Map<string, PlayerState>();

  private inputs = new Map<string, InputMsg[]>();
  private cooldowns = new Map<string, number[]>();
  private enemies = new Map<string, Enemy>();
  private deadAt = new Map<string, number>();
  private nextId = 0;
  private now = 0;           // simulation clock in ms (deterministic, testable)
  private advanceAt: number | null = null;

  constructor(private hooks: SimHooks) {}

  // ---- membership ---------------------------------------------------------
  addPlayer(id: string, name: string): boolean {
    if (this.phase !== 'lobby' || this.players.size >= MAX_PLAYERS || this.players.has(id)) return false;
    const def = CLASSES.warrior;
    this.players.set(id, {
      id, name: name.slice(0, 14) || 'Hero', classId: def.id, ready: false, alive: true,
      x: 200, y: ARENA.h / 2 + (this.players.size - 1.5) * 50,
      hp: def.stats.maxHp, maxHp: def.stats.maxHp, lastSeq: 0,
    });
    this.inputs.set(id, []);
    this.cooldowns.set(id, [0, 0, 0]);
    return true;
  }

  removePlayer(id: string): void {
    this.players.delete(id);
    this.inputs.delete(id);
    this.cooldowns.delete(id);
    if (this.phase === 'lobby') this.maybeStart(); else this.checkDefeat();
  }

  // ---- messages from players (untrusted: validate everything) -------------
  handle(id: string, msg: ClientMsg): void {
    const p = this.players.get(id);
    if (!p || typeof msg !== 'object' || msg === null) return;
    switch (msg.t) {
      case 'class': {
        const def = CLASSES[msg.classId as ClassId];
        if (!def || this.phase !== 'lobby') return;
        p.classId = def.id;
        p.maxHp = p.hp = def.stats.maxHp;
        break;
      }
      case 'ready':
        if (this.phase !== 'lobby') return;
        p.ready = msg.ready === true;
        this.maybeStart();
        break;
      case 'input': {
        const q = this.inputs.get(id);
        if (q && q.length < 10 && Number.isFinite(msg.dx) && Number.isFinite(msg.dy) && Number.isFinite(msg.seq)) {
          q.push({ seq: msg.seq, dx: msg.dx, dy: msg.dy });
        }
        break;
      }
      case 'ability':
        this.cast(p, msg.slot, msg.angle);
        break;
    }
  }

  // ---- run flow -----------------------------------------------------------
  private maybeStart(): void {
    const ps = [...this.players.values()];
    if (ps.length > 0 && ps.every((p) => p.ready)) {
      this.phase = 'playing';
      this.roomIndex = 0;
      this.spawnEncounter();
    }
  }

  private scale() { return { players: Math.max(1, this.players.size), floor: this.roomIndex + 1 }; }
  private newId(): string { return `e${this.nextId++}`; }

  private spawnEncounter(): void {
    const step = RUN_SCRIPT[this.roomIndex];
    if ('boss' in step) {
      this.enemies.set('boss', new Boss('boss', BOSSES[step.boss], ARENA.w - 300, ARENA.h / 2, this.scale()));
      return;
    }
    let i = 0;
    for (const [kind, n] of Object.entries(step.minions)) {
      for (let k = 0; k < n; k++, i++) {
        const a = (i / 8) * Math.PI * 2;
        const x = clamp(ARENA.w * 0.7 + Math.cos(a) * 220, 40, ARENA.w - 40);
        const y = clamp(ARENA.h / 2 + Math.sin(a) * 300, 40, ARENA.h - 40);
        const id = this.newId();
        this.enemies.set(id, new Minion(id, MINIONS[kind], x, y, this.scale()));
      }
    }
  }

  private checkDefeat(): void {
    if (this.phase !== 'playing') return;
    const ps = [...this.players.values()];
    if (ps.length > 0 && ps.every((p) => !p.alive)) this.phase = 'defeat';
  }

  // ---- simulation tick ----------------------------------------------------
  tick(dtMs: number): void {
    this.now += dtMs;
    if (this.phase !== 'playing') return;

    for (const [id, p] of this.players) {
      const q = this.inputs.get(id);
      if (!q) continue;
      if (!p.alive) { q.length = 0; continue; }
      const speed = CLASSES[p.classId as ClassId].stats.speed;
      for (const input of q.splice(0, MAX_INPUTS_PER_TICK)) {
        const pos = stepMovement(p, input.dx, input.dy, speed, TICK_MS);
        p.x = pos.x; p.y = pos.y; p.lastSeq = input.seq;
      }
    }

    for (const e of [...this.enemies.values()]) {
      e.update(dtMs, this.world);
      if (e.dead) {
        const since = this.deadAt.get(e.id) ?? this.now;
        this.deadAt.set(e.id, since);
        if (this.now - since > CORPSE_MS) { this.enemies.delete(e.id); this.deadAt.delete(e.id); }
      }
    }

    this.checkDefeat();
    this.checkRoomCleared();
  }

  private checkRoomCleared(): void {
    if (this.phase !== 'playing' || this.enemies.size > 0) return;
    if (this.roomIndex >= RUN_SCRIPT.length - 1) { this.phase = 'victory'; return; }
    if (this.advanceAt === null) { this.advanceAt = this.now + NEXT_ROOM_MS; return; }
    if (this.now >= this.advanceAt) {
      this.advanceAt = null;
      this.roomIndex++;
      for (const p of this.players.values()) { // between rooms: revive + heal 30%
        p.alive = true;
        p.hp = Math.min(p.maxHp, p.hp + p.maxHp * 0.3);
      }
      this.spawnEncounter();
    }
  }

  // ---- abilities ----------------------------------------------------------
  private cast(p: PlayerState, slot: number, angle: number): void {
    if (!p.alive || this.phase !== 'playing') return;
    if (slot !== 0 && slot !== 1 && slot !== 2) return;
    if (!Number.isFinite(angle)) return;
    const cls = CLASSES[p.classId as ClassId];
    const ab = cls.abilities[slot];
    const cd = this.cooldowns.get(p.id)!;
    if (this.now < cd[slot]) return;
    cd[slot] = this.now + ab.cooldownMs;

    const dmg = ab.damage * cls.stats.power;
    const live = [...this.enemies.values()].filter((e) => !e.dead);

    switch (ab.kind) {
      case 'cone':
        for (const e of live) {
          if (inCone(p.x, p.y, angle, (ab.arcDeg * Math.PI) / 180, ab.range, e.x, e.y, e.def.radius)) e.takeDamage(dmg);
        }
        this.hooks.fx({ kind: 'hit', x: p.x, y: p.y, r: ab.range, ms: 150, angle, arc: ab.arcDeg });
        break;
      case 'circle': {
        const cx = p.x + Math.cos(angle) * ab.range;
        const cy = p.y + Math.sin(angle) * ab.range;
        for (const e of live) if (inCircle(cx, cy, ab.radius, e.x, e.y, e.def.radius)) e.takeDamage(dmg);
        this.hooks.fx({ kind: 'hit', x: cx, y: cy, r: ab.radius, ms: 250 });
        break;
      }
      case 'ray': {
        const bx = p.x + Math.cos(angle) * ab.range;
        const by = p.y + Math.sin(angle) * ab.range;
        let best: Enemy | null = null;
        let bestT = Infinity;
        for (const e of live) {
          const { d, t } = pointSegment(p.x, p.y, bx, by, e.x, e.y);
          if (d <= ab.radius + e.def.radius && t < bestT) { best = e; bestT = t; }
        }
        best?.takeDamage(dmg);
        this.hooks.fx({ kind: 'dash', x: p.x, y: p.y, r: ab.range * (best ? bestT : 1), ms: 120, angle });
        break;
      }
      case 'dash':
        p.x = clamp(p.x + Math.cos(angle) * ab.range, 16, ARENA.w - 16);
        p.y = clamp(p.y + Math.sin(angle) * ab.range, 16, ARENA.h - 16);
        break;
    }
  }

  // ---- AI's view of the world --------------------------------------------
  private hurtPlayers(test: (p: PlayerState) => boolean, amount: number): void {
    for (const p of this.players.values()) {
      if (!p.alive || !test(p)) continue;
      const def = CLASSES[p.classId as ClassId].stats.defense;
      p.hp = Math.max(0, p.hp - Math.max(1, amount - def));
      if (p.hp <= 0) p.alive = false;
    }
  }

  private world: AIWorld = {
    players: () => [...this.players.values()].filter((p) => p.alive).map((p) => ({ id: p.id, x: p.x, y: p.y })),
    damageCircle: (x, y, r, amount) => this.hurtPlayers((p) => inCircle(x, y, r, p.x, p.y, 12), amount),
    damageCone: (x, y, facing, arcDeg, range, amount) =>
      this.hurtPlayers((p) => inCone(x, y, facing, (arcDeg * Math.PI) / 180, range, p.x, p.y, 12), amount),
    spawnMinion: (kind, x, y) => {
      const def = MINIONS[kind];
      if (!def) return;
      const id = this.newId();
      this.enemies.set(id, new Minion(id, def, x, y, this.scale()));
    },
    fx: (msg) => this.hooks.fx(msg),
  };

  // ---- replication --------------------------------------------------------
  snapshot(): Snapshot {
    const enemies: EnemyView[] = [...this.enemies.values()].map((e) => ({
      id: e.id, kind: e.def.id, isBoss: e instanceof Boss, ai: e.stateName, phase: e.phase,
      x: e.x, y: e.y, hp: e.hp, maxHp: e.maxHp, radius: e.def.radius, invulnerable: e.invulnerable,
    }));
    return { t: 'snap', phase: this.phase, roomIndex: this.roomIndex, players: [...this.players.values()].map((p) => ({ ...p })), enemies };
  }
}
