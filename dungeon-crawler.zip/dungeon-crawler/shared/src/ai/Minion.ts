import { EnemyDef } from '../enemies';
import { Enemy, Scaling } from './Enemy';

/** idle -> chase -> attack(windup, strike, recover) -> chase ... -> dead */
export class Minion extends Enemy {
  private t = 0;
  private struck = false;

  constructor(id: string, def: EnemyDef, x: number, y: number, scale: Scaling) {
    super(id, def, x, y, scale);

    this.fsm
      .add({
        name: 'idle',
        update: () => {
          const p = this.nearestPlayer();
          if (p && this.distTo(p) <= def.aggroRange) { this.targetId = p.id; return 'chase'; }
        },
      })
      .add({
        name: 'chase',
        update: (_o, dt) => {
          const p = this.target() ?? this.nearestPlayer();
          if (!p || this.distTo(p) > def.leashRange) { this.targetId = null; return 'idle'; }
          this.targetId = p.id;
          if (this.distTo(p) <= def.attackRange) return 'attack';
          this.moveToward(p, 1, dt);
        },
      })
      .add({
        name: 'attack',
        enter: () => {
          this.t = 0;
          this.struck = false;
          const p = this.target();
          if (p) this.facing = Math.atan2(p.y - this.y, p.x - this.x);
          this.world.fx({ kind: 'telegraph', x: this.x, y: this.y, r: def.attackRange + 10, ms: def.windupMs, angle: this.facing, arc: 90 });
        },
        update: (_o, dt) => {
          this.t += dt;
          if (!this.struck && this.t >= def.windupMs) {
            this.struck = true;
            this.world.damageCone(this.x, this.y, this.facing, 90, def.attackRange + 10, this.damage);
          }
          if (this.t >= def.windupMs + def.recoverMs) return 'chase';
        },
      })
      .add({ name: 'dead', update: () => {} })
      .start('idle');
  }
}
