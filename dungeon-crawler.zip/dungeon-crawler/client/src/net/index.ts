import { Capacitor } from '@capacitor/core';
import type { TransportFactory } from './Transport';
import { nearbyTransport } from './NearbyTransport';
import { tabTransport } from './TabTransport';

/** Android app → Bluetooth/Wi-Fi (Nearby). Dev server → browser tabs. Plain web → null (solo only). */
export function getTransport(): TransportFactory | null {
  if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') return nearbyTransport;
  if (import.meta.env.DEV) return tabTransport;
  return null;
}
