import Phaser from 'phaser';

/** Floating joystick: appears wherever the thumb lands on the left half of the screen. */
export class VirtualJoystick {
  vector = { x: 0, y: 0 };
  private base: Phaser.GameObjects.Arc;
  private knob: Phaser.GameObjects.Arc;
  private id: number | null = null;
  private ox = 0;
  private oy = 0;

  constructor(private scene: Phaser.Scene, private radius = 70) {
    this.base = scene.add.circle(0, 0, radius, 0xffffff, 0.1).setStrokeStyle(2, 0xffffff, 0.35).setVisible(false).setDepth(100);
    this.knob = scene.add.circle(0, 0, radius * 0.4, 0xffffff, 0.35).setVisible(false).setDepth(101);

    scene.input.on('pointerdown', (p: Phaser.Input.Pointer) => {
      if (this.id !== null || p.x > scene.scale.width * 0.5) return;
      this.id = p.id;
      this.ox = p.x; this.oy = p.y;
      this.base.setPosition(p.x, p.y).setVisible(true);
      this.knob.setPosition(p.x, p.y).setVisible(true);
    });
    scene.input.on('pointermove', (p: Phaser.Input.Pointer) => {
      if (p.id !== this.id) return;
      const dx = p.x - this.ox, dy = p.y - this.oy;
      const len = Math.hypot(dx, dy);
      const k = len > this.radius ? this.radius / len : 1;
      this.knob.setPosition(this.ox + dx * k, this.oy + dy * k);
      const m = Math.min(1, len / this.radius);
      this.vector = len < 8 ? { x: 0, y: 0 } : { x: (dx / len) * m, y: (dy / len) * m };
    });
    const release = (p: Phaser.Input.Pointer) => {
      if (p.id !== this.id) return;
      this.id = null;
      this.vector = { x: 0, y: 0 };
      this.base.setVisible(false);
      this.knob.setVisible(false);
    };
    scene.input.on('pointerup', release);
    scene.input.on('pointerupoutside', release);
  }
}
