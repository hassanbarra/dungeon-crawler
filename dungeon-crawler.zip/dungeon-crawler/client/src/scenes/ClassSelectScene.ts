import Phaser from 'phaser';
import { CLASSES, CLASS_IDS, ClassId } from '../../../shared/src/classes';
import { button, label } from './ui';

export class ClassSelectScene extends Phaser.Scene {
  constructor() { super('ClassSelect'); }

  create(): void {
    const { width: w, height: h } = this.scale;
    label(this, w / 2, 40, 'Choose your class', 30);

    let selected: ClassId = (this.registry.get('classId') as ClassId) ?? 'warrior';
    const frames: Phaser.GameObjects.Rectangle[] = [];

    CLASS_IDS.forEach((id, i) => {
      const def = CLASSES[id];
      const x = 170 + i * 310;
      const frame = this.add.rectangle(x, 255, 280, 330, 0x1b2130).setStrokeStyle(3, 0x333b50).setInteractive({ useHandCursor: true });
      frames.push(frame);
      this.add.image(x, 130, 'dot').setTint(def.color).setScale(2);
      label(this, x, 200, `${def.name}  ·  ${def.role.toUpperCase()}`, 22);
      label(this, x, 232, def.blurb, 13, '#8b93a7').setWordWrapWidth(250).setAlign('center');
      const s = def.stats;
      label(this, x, 285, `HP ${s.maxHp}   SPD ${s.speed}   PWR ${s.power}   DEF ${s.defense}`, 14, '#c9c6bb');
      def.abilities.forEach((a, k) => label(this, x, 320 + k * 26, `${k + 1}. ${a.name}  (${(a.cooldownMs / 1000).toFixed(1)}s)`, 15, '#a9b4cc'));
      frame.on('pointerup', () => { selected = id; paint(); });
    });

    const paint = () => frames.forEach((f, i) => f.setStrokeStyle(4, CLASS_IDS[i] === selected ? 0xe0a030 : 0x333b50));
    paint();

    button(this, 110, h - 40, 160, 'Back', () => this.scene.start('Menu'), 48);
    button(this, w - 150, h - 40, 240, 'Enter Lobby', () => { this.registry.set('classId', selected); this.scene.start('Lobby'); }, 48);
  }
}
