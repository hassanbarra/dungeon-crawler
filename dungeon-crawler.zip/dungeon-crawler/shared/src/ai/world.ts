import type { FxMsg, Vec2 } from '../protocol';

export interface Target extends Vec2 { id: string }

/** The only thing AI code knows about the game. Keeps AI unit-testable without Colyseus. */
export interface AIWorld {
  players(): Target[];
  damageCircle(x: number, y: number, r: number, amount: number): void;
  damageCone(x: number, y: number, facing: number, arcDeg: number, range: number, amount: number): void;
  spawnMinion(kind: string, x: number, y: number): void;
  fx(msg: FxMsg): void;
}
