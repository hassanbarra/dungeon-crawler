# Dungeon Crawler: Technical Blueprint (offline / local co-op)

1–4 players on nearby phones. **No internet, no server.** One phone is the **host** and runs the real game; the others join it over **Bluetooth / Wi-Fi** (Android Nearby Connections).

## 1. Stack

| Layer | Choice | Why |
|---|---|---|
| Game client | Phaser 3 + TypeScript + Vite | Fast iteration; same code runs on every phone |
| App shell | Capacitor (Android) | Packages the game as an APK and gives access to native Bluetooth/Wi-Fi |
| Phone-to-phone | Google **Nearby Connections**, `P2P_STAR` | Bluetooth + Wi-Fi handled for you, one host + several joiners, works offline |
| Game rules | `shared/src/sim/HostSim.ts` (pure TS) | Runs on the host phone only |

**Platform limits (important):** a web page cannot do Bluetooth multiplayer, so multiplayer is **Android-app only**. Phones in a plain browser get solo play. iPhone would need a second native plugin (Apple MultipeerConnectivity) behind the same `Transport` interface; not included.

## 2. Architecture: the host phone is the server

```
 Joiner phones (up to 3)                        HOST phone
 ┌──────────────────┐   input @20Hz             ┌────────────────────────────────┐
 │ Phaser client    │ ────────────────────────▶ │ HostSession                    │
 │ prediction       │   JSON over Bluetooth/    │  ├ HostSim (rules, enemy AI)   │
 │ interpolation    │   Wi-Fi (Nearby)          │  ├ host is also a player       │
 │ draws snapshots  │ ◀──────────────────────── │  └ snapshot @20Hz → everyone   │
 └──────────────────┘   snapshots + FX events   └────────────────────────────────┘
```

- **Host-authoritative.** Joiners send only intent (move vector, ability slot + angle). The host owns positions, HP, cooldowns, damage. The host phone also plays: it talks to its own sim through a loopback.
- **Transport interface** (`client/src/net/Transport.ts`): `HostTransport` / `ClientTransport`. Implementations: `NearbyTransport` (Android, native plugin) and `TabTransport` (browser tabs, **dev only**). Game code never knows which is in use.
- **Wire format:** JSON strings, ~1–2 KB per snapshot, 20 per second (Nearby bytes payloads cap at 32 KB).
- **Prediction + reconciliation** for your own character, **interpolation** for everyone else, same as before; the movement function is shared by host and clients.
- **Validation on the host:** inputs capped per tick, NaN rejected, cooldowns enforced, class change only in the lobby, lobby full/started → extra joiner is kicked.
- **Host keeps the screen awake** (`FLAG_KEEP_SCREEN_ON`). If the host leaves, everyone returns to the menu.

## 3. Classes
Data in `shared/src/classes.ts`: Warrior (tank), Mage (ranged DPS), Rogue (fast skirmisher), each with HP/speed/power/defense and three abilities of kind `cone`, `ray`, `circle` or `dash`. Tapping an ability auto-aims at the nearest enemy within 520 units, else along your move direction.

## 4. Enemies and bosses
`shared/src/ai/`: generic FSM; **Minion** idle → chase → attack(windup, strike, recover); **Boss** idle → engage → pattern(telegraph, execute, recover), with threshold-driven `transition` phases (60%, 30%) that pause, go invulnerable and spawn adds. All numbers are data in `shared/src/enemies.ts`. HP scales with party size and floor; damage scales with floor. A headless test with 3 bots (no dodging) played through room 1, room 2 and the boss and lost to the boss, which is the intended difficulty floor.

## 5. UI flow (landscape, mobile only)
```
Menu ─ Host Game ─┐
     ─ Join Game ─┼▶ Class Select ▶ Lobby (roster, ready) ▶ Game + HUD ▶ Victory/Defeat ▶ Menu
     ─ Play Solo ─┘
```
Joiners see a list of nearby games and tap one. Floating joystick (left half), three ability buttons (right), cooldown rings, boss bar, haptics. Desktop browsers see a "use your phone" screen; portrait shows a rotate prompt.

## 6. Build and run
See `PLAY.md`. Short version: run `build-apk.sh` (Mac/Linux) or `build-apk.bat` (Windows) → `apk/DungeonCrawler.apk`.

Dev on a desktop: `npm install && npm run dev`, open the URL with `?desktop` added in two tabs; one taps Host Game, the other Join Game (uses `TabTransport`).

## 7. Verification status (read this)
- **Verified:** all of `shared/` (rules, AI, protocol) and `client/src/net/` typecheck under `strict`. A headless run drove `HostSim` with 3 bot players through lobby → ready → rooms 1, 2, boss → defeat, plus a player leaving.
- **NOT verified:** the Phaser scenes, the `NearbyPlugin.java` Android code, the patch/build script, and any real phone-to-phone session. There was no network, Android SDK or device here. The Java plugin uses Capacitor/Nearby APIs from memory and may need small compile fixes; expect to iterate on first build.
- **Needs real devices to tune:** Bluetooth/Wi-Fi range and latency, how well the host phone holds 20 Hz with 3 joiners, battery and heat on the host.
- **Known gaps:** no reconnect after a drop; no walls or pathfinding; hitscan rays; placeholder circle art; auto-accept connections (anyone nearby running the game can join an open lobby; the host can see the roster).

## 8. Roadmap
1. Build the APK, test host + 1 joiner on two Android phones; fix plugin compile errors.
2. Reconnect support, in-game "connection lost" banner, host migration (optional).
3. Tilemap dungeon + pathfinding; wall collision in `stepMovement`.
4. iOS plugin (MultipeerConnectivity) behind the same `Transport`.
5. Real art/audio, progression saved on-device.
