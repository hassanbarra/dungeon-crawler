@echo off
REM One-click APK builder (Windows): double-click this file
cd /d "%~dp0"
node scripts\build-apk.mjs
pause
